<?php
$this->mysql_config_cache_file_time = 1326122288;
$this->timeline = 0;
$this->timezone = 28800;
$this->platform = 'WINDOWS';
?>