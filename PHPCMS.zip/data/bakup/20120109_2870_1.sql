# phpmps bakfile
# version:2.2
# time:2012-01-09 14:35:19
# --------------------------------------------------------


DROP TABLE IF EXISTS phpmps_about;
CREATE TABLE `phpmps_about` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `postdate` int(11) NOT NULL,
  `url` varchar(100) NOT NULL,
  `aboutorder` smallint(5) NOT NULL default '0',
  `is_show` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `is_show` (`is_show`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_admin;
CREATE TABLE `phpmps_admin` (
  `userid` smallint(5) unsigned NOT NULL auto_increment,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `truename` varchar(30) NOT NULL,
  `email` varchar(35) NOT NULL,
  `purview` text NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `lastip` varchar(15) NOT NULL,
  `lastlogin` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`userid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_admin VALUES('1','admin','21232f297a57a5a743894a0e4a801fc3','','admin@admin.com','','1','192.168.1.12','1326104132');

DROP TABLE IF EXISTS phpmps_admin_log;
CREATE TABLE `phpmps_admin_log` (
  `logid` int(10) unsigned NOT NULL auto_increment,
  `adminname` varchar(32) NOT NULL,
  `logdate` int(10) unsigned NOT NULL,
  `logtype` varchar(255) NOT NULL,
  `logip` varchar(15) NOT NULL,
  PRIMARY KEY  (`logid`)
) ENGINE=MyISAM AUTO_INCREMENT=232 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_admin_log VALUES('1','admin','1326104132','admin 登陆成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('2','admin','1326106602','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('3','admin','1326106639','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('4','admin','1326106656','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('5','admin','1326106691','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('6','admin','1326106722','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('7','admin','1326106857','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('8','admin','1326108200','编辑链接 php分类信息 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('9','admin','1326109208','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('10','admin','1326109344','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('11','admin','1326109401','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('12','admin','1326109462','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('13','admin','1326109506','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('14','admin','1326109565','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('15','admin','1326109617','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('16','admin','1326109644','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('17','admin','1326109669','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('18','admin','1326109715','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('19','admin','1326109765','编辑分类 物品交易 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('20','admin','1326109780','编辑分类 车辆买卖 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('21','admin','1326109797','插入地区 秦州区 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('22','admin','1326109803','插入地区 麦积区 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('23','admin','1326109810','插入地区 武山县 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('24','admin','1326109815','插入地区 甘谷县 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('25','admin','1326109836','插入地区 秦安县 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('26','admin','1326109852','插入地区 张家川 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('27','admin','1326109864','插入地区 甘谷县 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('28','admin','1326109911','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('29','admin','1326109932','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('30','admin','1326109945','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('31','admin','1326109997','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('32','admin','1326110006','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('33','admin','1326110022','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('34','admin','1326110034','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('35','admin','1326110045','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('36','admin','1326110052','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('37','admin','1326110076','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('38','admin','1326110086','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('39','admin','1326110105','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('40','admin','1326110116','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('41','admin','1326110126','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('42','admin','1326110142','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('43','admin','1326110154','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('44','admin','1326110161','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('45','admin','1326110173','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('46','admin','1326110195','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('47','admin','1326110207','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('48','admin','1326110216','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('49','admin','1326110232','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('50','admin','1326110243','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('51','admin','1326110255','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('52','admin','1326110265','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('53','admin','1326110276','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('54','admin','1326110284','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('55','admin','1326110297','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('56','admin','1326110308','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('57','admin','1326110318','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('58','admin','1326110329','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('59','admin','1326110343','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('60','admin','1326110350','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('61','admin','1326110362','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('62','admin','1326110369','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('63','admin','1326110376','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('64','admin','1326110388','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('65','admin','1326110412','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('66','admin','1326110437','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('67','admin','1326110454','编辑分类 房屋出租 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('68','admin','1326110480','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('69','admin','1326110492','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('70','admin','1326110502','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('71','admin','1326110529','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('72','admin','1326110540','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('73','admin','1326110559','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('74','admin','1326110701','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('75','admin','1326110711','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('76','admin','1326110732','编辑分类 商务房 成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('77','admin','1326110751','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('78','admin','1326110763','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('79','admin','1326110777','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('80','admin','1326110791','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('81','admin','1326110809','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('82','admin','1326110827','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('83','admin','1326110842','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('84','admin','1326110858','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('85','admin','1326110871','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('86','admin','1326110880','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('87','admin','1326110893','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('88','admin','1326110921','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('89','admin','1326110935','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('90','admin','1326110948','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('91','admin','1326110966','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('92','admin','1326110978','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('93','admin','1326110992','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('94','admin','1326111010','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('95','admin','1326111027','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('96','admin','1326111040','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('97','admin','1326111052','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('98','admin','1326111062','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('99','admin','1326111073','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('100','admin','1326111090','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('101','admin','1326111116','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('102','admin','1326111172','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('103','admin','1326111195','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('104','admin','1326111218','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('105','admin','1326111249','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('106','admin','1326111310','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('107','admin','1326111323','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('108','admin','1326111337','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('109','admin','1326111357','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('110','admin','1326111369','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('111','admin','1326111387','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('112','admin','1326111408','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('113','admin','1326111424','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('114','admin','1326111436','插入分类  成功','192.168.1.4');
INSERT INTO phpmps_admin_log VALUES('115','admin','1326111496','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('116','admin','1326111515','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('117','admin','1326111530','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('118','admin','1326111543','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('119','admin','1326111569','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('120','admin','1326111580','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('121','admin','1326111599','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('122','admin','1326111612','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('123','admin','1326111624','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('124','admin','1326111651','编辑分类 家居装修 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('125','admin','1326111665','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('126','admin','1326111674','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('127','admin','1326111686','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('128','admin','1326111696','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('129','admin','1326111714','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('130','admin','1326111746','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('131','admin','1326111790','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('132','admin','1326111805','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('133','admin','1326111815','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('134','admin','1326111831','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('135','admin','1326111840','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('136','admin','1326111854','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('137','admin','1326111872','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('138','admin','1326111889','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('139','admin','1326111910','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('140','admin','1326111950','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('141','admin','1326111961','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('142','admin','1326111972','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('143','admin','1326111984','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('144','admin','1326111995','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('145','admin','1326112005','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('146','admin','1326112017','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('147','admin','1326112033','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('148','admin','1326112043','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('149','admin','1326112055','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('150','admin','1326112128','编辑分类 二手台式电脑 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('151','admin','1326112294','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('152','admin','1326112306','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('153','admin','1326112317','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('154','admin','1326112328','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('155','admin','1326112365','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('156','admin','1326112378','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('157','admin','1326112400','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('158','admin','1326112423','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('159','admin','1326112438','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('160','admin','1326112462','编辑分类 征婚交友/同城活动 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('161','admin','1326112588','编辑分类 技能交换 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('162','admin','1326112640','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('163','admin','1326112657','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('164','admin','1326112715','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('165','admin','1326112730','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('166','admin','1326112782','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('167','admin','1326112818','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('168','admin','1326112845','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('169','admin','1326112860','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('170','admin','1326112877','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('171','admin','1326112889','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('172','admin','1326112933','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('173','admin','1326112946','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('174','admin','1326112967','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('175','admin','1326112991','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('176','admin','1326113002','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('177','admin','1326113014','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('178','admin','1326113025','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('179','admin','1326113035','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('180','admin','1326113046','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('181','admin','1326113055','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('182','admin','1326113069','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('183','admin','1326113096','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('184','admin','1326113179','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('185','admin','1326113193','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('186','admin','1326113209','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('187','admin','1326113230','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('188','admin','1326113247','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('189','admin','1326113262','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('190','admin','1326113279','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('191','admin','1326113290','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('192','admin','1326113304','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('193','admin','1326113316','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('194','admin','1326113327','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('195','admin','1326113342','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('196','admin','1326113361','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('197','admin','1326113377','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('198','admin','1326113399','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('199','admin','1326113409','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('200','admin','1326113588','编辑分类 笔记本/IPAD 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('201','admin','1326114313','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('202','admin','1326114364','编辑链接 天水网 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('203','admin','1326114439','添加链接 天水新闻 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('204','admin','1326114463','添加链接 甘谷新闻网 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('205','admin','1326114493','添加链接 秦州新闻网 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('206','admin','1326114540','添加链接 麦积新闻网 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('207','admin','1326114562','添加链接 秦安新闻网 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('208','admin','1326114589','添加链接 张川新闻网 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('209','admin','1326114624','添加链接 五山新闻网 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('210','admin','1326114649','添加链接 清水新闻网 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('211','admin','1326114667','编辑链接 武山新闻网 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('212','admin','1326114877','删除导航 2,3 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('213','admin','1326114940','添加导航 教育培训 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('214','admin','1326115022','添加导航 个人求职 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('215','admin','1326115049','添加导航 企业招聘 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('216','admin','1326115075','添加导航 房屋租售 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('217','admin','1326115104','添加导航 交友活动 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('218','admin','1326115516','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('219','admin','1326115544','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('220','admin','1326115679','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('221','admin','1326116090','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('222','admin','1326116221','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('223','admin','1326116373','添加广告位  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('224','admin','1326116393','添加广告 index_top 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('225','admin','1326116507','修改广告 index_top 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('226','admin','1326117364','添加导航 物品交易 成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('227','admin','1326119444','修改配制成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('228','admin','1326119521','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('229','admin','1326119528','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('230','admin','1326119534','插入分类  成功','192.168.1.12');
INSERT INTO phpmps_admin_log VALUES('231','admin','1326119676','修改配制成功','192.168.1.12');

DROP TABLE IF EXISTS phpmps_ads;
CREATE TABLE `phpmps_ads` (
  `adsid` smallint(5) unsigned NOT NULL auto_increment,
  `placeid` smallint(5) unsigned NOT NULL,
  `adsname` varchar(32) NOT NULL,
  `adstype` tinyint(3) NOT NULL,
  `adsurl` varchar(150) NOT NULL,
  `adscode` text NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `updatetime` int(11) NOT NULL,
  `linkman` varchar(32) NOT NULL,
  PRIMARY KEY  (`adsid`),
  KEY `adsname` (`adsname`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_ads VALUES('1','1','index_top','4','','<img src=\"http://img1.tuniucdn.com/u/gg/union/201107/468x60.jpg\">','1326116393','1326116507','');

DROP TABLE IF EXISTS phpmps_ads_place;
CREATE TABLE `phpmps_ads_place` (
  `placeid` int(11) unsigned NOT NULL auto_increment,
  `placename` varchar(32) NOT NULL,
  `width` smallint(5) unsigned NOT NULL,
  `height` smallint(5) unsigned NOT NULL,
  `introduce` varchar(100) NOT NULL,
  PRIMARY KEY  (`placeid`),
  KEY `placename` (`placename`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_ads_place VALUES('1','index_top','468','60','');

DROP TABLE IF EXISTS phpmps_area;
CREATE TABLE `phpmps_area` (
  `areaid` mediumint(6) NOT NULL auto_increment,
  `areaname` varchar(32) NOT NULL,
  `parentid` int(11) unsigned NOT NULL,
  `areaorder` smallint(6) NOT NULL,
  PRIMARY KEY  (`areaid`),
  KEY `areaname` (`areaname`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_area VALUES('1','秦州区','0','1');
INSERT INTO phpmps_area VALUES('2','麦积区','0','2');
INSERT INTO phpmps_area VALUES('3','武山县','0','3');
INSERT INTO phpmps_area VALUES('4','甘谷县','0','4');
INSERT INTO phpmps_area VALUES('5','秦安县','0','5');
INSERT INTO phpmps_area VALUES('6','张家川','0','6');
INSERT INTO phpmps_area VALUES('7','甘谷县','0','7');

DROP TABLE IF EXISTS phpmps_article;
CREATE TABLE `phpmps_article` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `typeid` smallint(5) NOT NULL,
  `title` varchar(100) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `thumb` varchar(50) NOT NULL,
  `listorder` smallint(5) NOT NULL default '0',
  `addtime` int(11) NOT NULL,
  `is_index` tinyint(1) unsigned NOT NULL,
  `is_pro` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `is_index` (`is_index`),
  KEY `addtime` (`addtime`),
  KEY `is_pro` (`is_pro`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_category;
CREATE TABLE `phpmps_category` (
  `catid` mediumint(6) NOT NULL auto_increment,
  `catname` varchar(32) NOT NULL,
  `keywords` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  `parentid` int(11) default NULL,
  `catorder` smallint(6) NOT NULL,
  `cattplname` varchar(30) NOT NULL,
  `viewtplname` varchar(30) NOT NULL,
  PRIMARY KEY  (`catid`),
  KEY `parentid` (`parentid`),
  KEY `catname` (`catname`)
) ENGINE=MyISAM AUTO_INCREMENT=177 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_category VALUES('1','物品交易','物品交易\r\n二手台式电脑 电脑配件/宽带 笔记本/iPad 二手手机 手机号码交易 照相机/摄像机 MP3/游戏机 日用品 食品 二手家用电器 二手家具 办公家具/耗材 收藏品/工艺品 女装/男装 配饰/钟表 鞋帽/箱包 化妆品 母婴/幼儿/玩具 书报/音像 二手乐器/文具 二手运动器材 消费卡/优惠券 门票/电影票 火车票/汽车票 工业设备 其他转让物品 物品交换 求购','天水信息网，物品交易栏目包括： 物品交易\r\n二手台式电脑 电脑配件/宽带 笔记本/iPad 二手手机 手机号码交易 照相机/摄像机 MP3/游戏机 日用品 食品 二手家用电器 二手家具 办公家具/耗材 收藏品/工艺品 女装/男装 配饰/钟表 鞋帽/箱包 化妆品 母婴/幼儿/玩具 书报/音像 二手乐器/文具 二手运动器材 消费卡/优惠券 门票/电影票 火车票/汽车票 工业设备 其他转让物品 物品交换 求购','0','1','0','0');
INSERT INTO phpmps_category VALUES('2','车辆买卖','车辆买卖，二手车，汽车用品，汽车配件，摩托车，电动车，自行车，新车，汽车4S店','天水信息网车辆买卖栏目二手车 汽车用品/配件 摩托车/燃气车 电动车 自行车 车辆求购 租车 新车 4S店/经销商 陪驾/代驾','0','2','0','0');
INSERT INTO phpmps_category VALUES('3','房屋租售','天水房屋租售，房屋出租，房屋合租，二手房买卖 新房出售 短租房/日租房 写字楼租售 生意/商铺/办公房 厂房/仓库/土地','天水信息网房屋租售栏目包括天水房屋租售，房屋出租，房屋合租，二手房买卖 新房出售 短租房/日租房 写字楼租售 生意/商铺/办公房 厂房/仓库/土地','0','3','0','0');
INSERT INTO phpmps_category VALUES('4','招聘工作','营业员 店长 服务员 收银员 销售/业务员 房地产 保险 文员 助理天水招聘 前台 行政 人事 客服 市场/运营 家政/保洁 司机 保安 厨师 切配 送货员 快递员 仓管 网管 工人/技工 财务/会计/出纳 IT/互联网 教育/培训/咨询 广告/媒体/设计 建筑/装潢/园林 编辑 摄影 翻译 美容美发 保健按摩 招聘会 KTV/酒吧 其他招聘','天水信息网求职招聘栏目包括：营业员 店长 服务员 收银员 销售/业务员 房地产 保险 文员 助理 前台 行政 人事 客服 市场/运营 家政/保洁 司机 保安 厨师 切配 送货员 快递员 仓管 网管 工人/技工 财务/会计/出纳 IT/互联网 教育/培训/咨询 广告/媒体/设计 建筑/装潢/园林 编辑 摄影 翻译 美容美发 保健按摩 招聘会 KTV/酒吧 其他招聘','0','4','0','0');
INSERT INTO phpmps_category VALUES('5','生活服务','租车 驾校 陪驾/代驾 汽车检修/保养 家政保姆服务 保洁清洗服务 装修 疏通 建材装饰 家居维修 搬家 快递/物流 电脑维修 家电维修 招商加盟/代理 公司注册/年检 担保/贷款 投资理财/保险 会计/审计/评估 旅游 酒店 机票/签证 网站建设/推广 鲜花 礼品/定制 美容纤体 婚庆/化妆/司仪 摄影服务 设计策划 印刷/喷绘招牌 翻译 律师 物品/设备租赁 物品回收 其他服务 技能交换','天水信息网生活服务栏目包括：租车 驾校 陪驾/代驾 汽车检修/保养 家政保姆服务 保洁清洗服务 装修 疏通 建材装饰 家居维修 搬家 快递/物流 电脑维修 家电维修 招商加盟/代理 公司注册/年检 担保/贷款 投资理财/保险 会计/审计/评估 旅游 酒店 机票/签证 网站建设/推广 鲜花 礼品/定制 美容纤体 婚庆/化妆/司仪 摄影服务 设计策划 印刷/喷绘招牌 翻译 律师 物品/设备租赁 物品回收 其他服务 技能交换','0','5','0','0');
INSERT INTO phpmps_category VALUES('6','征婚交友/同城活动','男士征婚 女士征婚 找男朋友 找女朋友 拼车顺风车 同城聚会 运动打球 结伴出游 寻人/寻物 同乡会 同学会 兴趣交友 真情告白/祝福','天水信息网征婚交友栏目包括：男士征婚 女士征婚 找男朋友 找女朋友 拼车顺风车 同城聚会 运动打球 结伴出游 寻人/寻物 同乡会 同学会 兴趣交友 真情告白/祝福','0','6','0','0');
INSERT INTO phpmps_category VALUES('7','兼职实习','家教 会计 模特 礼仪 设计 网站 摄影 演员 翻译 客服 其他兼职 实习生 销售 派发 促销 临时工/小时工 充场/座谈会','天水信息网兼职实习栏目包括：家教 会计 模特 礼仪 设计 网站 摄影 演员 翻译 客服 其他兼职 实习生 销售 派发 促销 临时工/小时工 充场/座谈会','0','7','0','0');
INSERT INTO phpmps_category VALUES('8','宠物','宠物狗 猫/其他宠物 宠物免费赠送 宠物用品/食品 宠物服务/配种 犬舍/宠物店','天水信息网宠物频道包括：宠物狗 猫/其他宠物 宠物免费赠送 宠物用品/食品 宠物服务/配种 犬舍/宠物店','0','8','0','0');
INSERT INTO phpmps_category VALUES('9','教育培训','电脑培训 外语培训 学历教育 婴幼儿教育 设计培训 职业技能培训 文艺/体育培训 中小学教育','天水信息网教育培训包括：电脑培训 外语培训 学历教育 婴幼儿教育 设计培训 职业技能培训 文艺/体育培训 中小学教育','0','9','0','0');
INSERT INTO phpmps_category VALUES('10','求职简历','全职求职简历 兼职求职简历','天水信息网求职简历包括：全职求职简历 兼职求职简历','0','10','0','0');
INSERT INTO phpmps_category VALUES('11','二手台式电脑','二手台式电脑','二手台式电脑','1','11','0','0');
INSERT INTO phpmps_category VALUES('12','电脑配件/宽带','电脑配件，宽带','电脑配件，宽带','1','12','0','0');
INSERT INTO phpmps_category VALUES('13','笔记本/IPAD','','','1','13','0','0');
INSERT INTO phpmps_category VALUES('14','手机交易','','','1','14','0','0');
INSERT INTO phpmps_category VALUES('15','手机号码交易','','','1','15','0','0');
INSERT INTO phpmps_category VALUES('16','照相机/摄像机','','','1','16','0','0');
INSERT INTO phpmps_category VALUES('17','MP3游戏机','','','1','17','0','0');
INSERT INTO phpmps_category VALUES('18','日用品','','','1','18','0','0');
INSERT INTO phpmps_category VALUES('19','食品','','','1','19','0','0');
INSERT INTO phpmps_category VALUES('20','二手家用电器','','','1','20','0','0');
INSERT INTO phpmps_category VALUES('21','二手家具','','','1','21','0','0');
INSERT INTO phpmps_category VALUES('22','办公耗材/家具','','','1','22','0','0');
INSERT INTO phpmps_category VALUES('23','收藏品/工艺品','','','1','23','0','0');
INSERT INTO phpmps_category VALUES('24','女装/男装','','','1','24','0','0');
INSERT INTO phpmps_category VALUES('25','配饰/钟表','','','1','25','0','0');
INSERT INTO phpmps_category VALUES('26','箱包/鞋帽','','','1','26','0','0');
INSERT INTO phpmps_category VALUES('27','化妆品','','','1','27','0','0');
INSERT INTO phpmps_category VALUES('28','母婴/幼儿玩具','','','1','28','0','0');
INSERT INTO phpmps_category VALUES('29','书报/音响','','','1','29','0','0');
INSERT INTO phpmps_category VALUES('30','二手乐器/文具','','','1','30','0','0');
INSERT INTO phpmps_category VALUES('31','二手运动器材','','','1','31','0','0');
INSERT INTO phpmps_category VALUES('32','消费卡/优惠劵','','','1','32','0','0');
INSERT INTO phpmps_category VALUES('33','门票/电影票','','','1','33','0','0');
INSERT INTO phpmps_category VALUES('34','火车票/汽车票','','','1','34','0','0');
INSERT INTO phpmps_category VALUES('35','工业设备','','','1','35','0','0');
INSERT INTO phpmps_category VALUES('36','其他转让物品','','','1','36','0','0');
INSERT INTO phpmps_category VALUES('37','物品交换','','','1','37','0','0');
INSERT INTO phpmps_category VALUES('38','物品求购','','','1','38','0','0');
INSERT INTO phpmps_category VALUES('39','二手车','','','2','39','0','0');
INSERT INTO phpmps_category VALUES('40','汽车用品/配件','','','2','40','0','0');
INSERT INTO phpmps_category VALUES('41','摩托车/燃气车','','','2','41','0','0');
INSERT INTO phpmps_category VALUES('42','电动车','','','2','42','0','0');
INSERT INTO phpmps_category VALUES('43','自行车','','','2','43','0','0');
INSERT INTO phpmps_category VALUES('44','车辆求购','','','2','44','0','0');
INSERT INTO phpmps_category VALUES('45','租车','','','2','45','0','0');
INSERT INTO phpmps_category VALUES('46','新车','','','2','46','0','0');
INSERT INTO phpmps_category VALUES('47','4S店/经销商','','','2','47','0','0');
INSERT INTO phpmps_category VALUES('48','房屋出租','','','3','48','0','0');
INSERT INTO phpmps_category VALUES('49','房屋求租','','','3','49','0','0');
INSERT INTO phpmps_category VALUES('50','房屋合租','','','3','50','0','0');
INSERT INTO phpmps_category VALUES('51','二手房买卖','','','3','51','0','0');
INSERT INTO phpmps_category VALUES('52','新房出售','','','3','52','0','0');
INSERT INTO phpmps_category VALUES('53','短租房/日租房','','','3','53','0','0');
INSERT INTO phpmps_category VALUES('54','写字楼租售','','','3','54','0','0');
INSERT INTO phpmps_category VALUES('55','生意/商场/办公房','','','3','55','0','0');
INSERT INTO phpmps_category VALUES('56','商务房','','','3','56','0','0');
INSERT INTO phpmps_category VALUES('57','厂房/仓库/土地','','','3','57','0','0');
INSERT INTO phpmps_category VALUES('58','营业员','','','4','58','0','0');
INSERT INTO phpmps_category VALUES('59','店长','','','4','59','0','0');
INSERT INTO phpmps_category VALUES('60','服务员','','','4','60','0','0');
INSERT INTO phpmps_category VALUES('61','收银员','','','4','61','0','0');
INSERT INTO phpmps_category VALUES('62','销售/业务员','','','4','62','0','0');
INSERT INTO phpmps_category VALUES('63','房产类工作','','','4','63','0','0');
INSERT INTO phpmps_category VALUES('64','金融保险','','','4','64','0','0');
INSERT INTO phpmps_category VALUES('65','文员/办公','','','4','65','0','0');
INSERT INTO phpmps_category VALUES('66','商务助理','','','4','66','0','0');
INSERT INTO phpmps_category VALUES('67','前台','','','4','67','0','0');
INSERT INTO phpmps_category VALUES('68','行政工作','','','4','68','0','0');
INSERT INTO phpmps_category VALUES('69','人事','','','4','69','0','0');
INSERT INTO phpmps_category VALUES('70','客服','','','4','70','0','0');
INSERT INTO phpmps_category VALUES('71','市场运营','','','4','71','0','0');
INSERT INTO phpmps_category VALUES('72','家政保洁','','','4','72','0','0');
INSERT INTO phpmps_category VALUES('73','司机工作','','','4','73','0','0');
INSERT INTO phpmps_category VALUES('74','保安','','','4','74','0','0');
INSERT INTO phpmps_category VALUES('75','厨师','','','4','75','0','0');
INSERT INTO phpmps_category VALUES('76','切配','','','4','76','0','0');
INSERT INTO phpmps_category VALUES('77','送货员工作','','','4','77','0','0');
INSERT INTO phpmps_category VALUES('78','快递员工作','','','4','78','0','0');
INSERT INTO phpmps_category VALUES('79','仓管','','','4','79','0','0');
INSERT INTO phpmps_category VALUES('80','网管工作','','','4','80','0','0');
INSERT INTO phpmps_category VALUES('81','招聘工人技工','','','4','81','0','0');
INSERT INTO phpmps_category VALUES('82','招聘财务/会计出纳','','','4','82','0','0');
INSERT INTO phpmps_category VALUES('83','招聘IT/互联网','','','4','83','0','0');
INSERT INTO phpmps_category VALUES('84','[招聘]教育培训/咨询','','','4','84','0','0');
INSERT INTO phpmps_category VALUES('85','[招聘]广告/媒体/设计','','','4','85','0','0');
INSERT INTO phpmps_category VALUES('86','招聘建筑/装潢/园林','','','4','86','0','0');
INSERT INTO phpmps_category VALUES('87','招聘编辑','','','4','87','0','0');
INSERT INTO phpmps_category VALUES('88','招聘摄影','','','4','88','0','0');
INSERT INTO phpmps_category VALUES('89','招聘翻译','','','4','89','0','0');
INSERT INTO phpmps_category VALUES('90','招聘美容美发','','','4','90','0','0');
INSERT INTO phpmps_category VALUES('91','保健按摩','','','4','91','0','0');
INSERT INTO phpmps_category VALUES('92','招聘会','','','4','92','0','0');
INSERT INTO phpmps_category VALUES('93','招聘KTV/酒吧','','','4','93','0','0');
INSERT INTO phpmps_category VALUES('94','其他招聘工作','','','4','94','0','0');
INSERT INTO phpmps_category VALUES('95','租车','','','5','95','0','0');
INSERT INTO phpmps_category VALUES('96','驾校','','','5','96','0','0');
INSERT INTO phpmps_category VALUES('97','陪驾/代驾服务','','','5','97','0','0');
INSERT INTO phpmps_category VALUES('98','汽车检修/保养','','','5','98','0','0');
INSERT INTO phpmps_category VALUES('99','家政保姆服务','','','5','99','0','0');
INSERT INTO phpmps_category VALUES('100','保洁清洗服务','','','5','100','0','0');
INSERT INTO phpmps_category VALUES('101','装修服务','','','5','101','0','0');
INSERT INTO phpmps_category VALUES('102','下水管疏通','','','5','102','0','0');
INSERT INTO phpmps_category VALUES('103','建筑装饰','','','5','103','0','0');
INSERT INTO phpmps_category VALUES('104','家居装修','','','5','104','0','0');
INSERT INTO phpmps_category VALUES('105','搬家服务','','','5','105','0','0');
INSERT INTO phpmps_category VALUES('106','快递物流','','','5','106','0','0');
INSERT INTO phpmps_category VALUES('107','电脑维修','','','5','107','0','0');
INSERT INTO phpmps_category VALUES('108','家电维修','','','5','108','0','0');
INSERT INTO phpmps_category VALUES('109','招商/加盟/代理','','','5','109','0','0');
INSERT INTO phpmps_category VALUES('110','公司注册/年检','','','5','110','0','0');
INSERT INTO phpmps_category VALUES('111','担保贷款','','','5','111','0','0');
INSERT INTO phpmps_category VALUES('112','投资理财/保险','','','5','112','0','0');
INSERT INTO phpmps_category VALUES('113','会计/审计/评估','','','5','113','0','0');
INSERT INTO phpmps_category VALUES('114','旅游','','','5','114','0','0');
INSERT INTO phpmps_category VALUES('115','酒店','','','5','115','0','0');
INSERT INTO phpmps_category VALUES('116','机票/签证','','','5','116','0','0');
INSERT INTO phpmps_category VALUES('117','网站建设/推广','','','5','117','0','0');
INSERT INTO phpmps_category VALUES('118','鲜花礼仪','','','5','118','0','0');
INSERT INTO phpmps_category VALUES('119','礼品/定制','','','5','119','0','0');
INSERT INTO phpmps_category VALUES('120','美容美体','','','5','120','0','0');
INSERT INTO phpmps_category VALUES('121','婚庆/化妆/司仪','','','5','121','0','0');
INSERT INTO phpmps_category VALUES('122','摄影服务','','','5','122','0','0');
INSERT INTO phpmps_category VALUES('123','设计策划','','','5','123','0','0');
INSERT INTO phpmps_category VALUES('124','广告印刷','','','5','124','0','0');
INSERT INTO phpmps_category VALUES('125','翻译','','','5','125','0','0');
INSERT INTO phpmps_category VALUES('126','律师','','','5','126','0','0');
INSERT INTO phpmps_category VALUES('127','物品/设备租赁','','','5','127','0','0');
INSERT INTO phpmps_category VALUES('128','物品回收','','','5','128','0','0');
INSERT INTO phpmps_category VALUES('129','其他服务','','','5','129','0','0');
INSERT INTO phpmps_category VALUES('130','男士征婚','','','6','130','0','0');
INSERT INTO phpmps_category VALUES('131','女士征婚','','','6','131','0','0');
INSERT INTO phpmps_category VALUES('132','找男朋友','','','6','132','0','0');
INSERT INTO phpmps_category VALUES('133','找女朋友','','','6','133','0','0');
INSERT INTO phpmps_category VALUES('134','拼车/顺风车','','','6','134','0','0');
INSERT INTO phpmps_category VALUES('135','同城聚会','','','6','135','0','0');
INSERT INTO phpmps_category VALUES('136','运动打球','','','6','136','0','0');
INSERT INTO phpmps_category VALUES('137','结伴出游','','','6','137','0','0');
INSERT INTO phpmps_category VALUES('138','技能交换','','','6','138','0','0');
INSERT INTO phpmps_category VALUES('139','寻人/寻物','','','6','139','0','0');
INSERT INTO phpmps_category VALUES('140','老乡会','','','6','140','0','0');
INSERT INTO phpmps_category VALUES('141','同学会','','','6','141','0','0');
INSERT INTO phpmps_category VALUES('142','兴趣交友','','','6','142','0','0');
INSERT INTO phpmps_category VALUES('143','真情告白/祝福','','','6','143','0','0');
INSERT INTO phpmps_category VALUES('144','家教','','','7','144','0','0');
INSERT INTO phpmps_category VALUES('145','会计','','','7','145','0','0');
INSERT INTO phpmps_category VALUES('146','模特','','','7','146','0','0');
INSERT INTO phpmps_category VALUES('147','礼仪','','','7','147','0','0');
INSERT INTO phpmps_category VALUES('148','设计','','','7','148','0','0');
INSERT INTO phpmps_category VALUES('149','网站','','','7','149','0','0');
INSERT INTO phpmps_category VALUES('150','摄影','','','7','150','0','0');
INSERT INTO phpmps_category VALUES('151','演员','','','7','151','0','0');
INSERT INTO phpmps_category VALUES('152','翻译','','','7','152','0','0');
INSERT INTO phpmps_category VALUES('153','客服','','','7','153','0','0');
INSERT INTO phpmps_category VALUES('154','其他兼职','','','7','154','0','0');
INSERT INTO phpmps_category VALUES('155','实习生','','','7','155','0','0');
INSERT INTO phpmps_category VALUES('156','销售','','','7','156','0','0');
INSERT INTO phpmps_category VALUES('157','派发','','','7','157','0','0');
INSERT INTO phpmps_category VALUES('158','促销','','','7','158','0','0');
INSERT INTO phpmps_category VALUES('159','临时工/小时工','','','7','159','0','0');
INSERT INTO phpmps_category VALUES('160','充场/座谈会','','','7','160','0','0');
INSERT INTO phpmps_category VALUES('161','宠物狗','','','8','161','0','0');
INSERT INTO phpmps_category VALUES('162','猫/其他宠物','','','8','162','0','0');
INSERT INTO phpmps_category VALUES('163','宠物免费收养','','','8','163','0','0');
INSERT INTO phpmps_category VALUES('164','宠物用品/食品','','','8','164','0','0');
INSERT INTO phpmps_category VALUES('165','宠物医院','','','8','165','0','0');
INSERT INTO phpmps_category VALUES('166','犬舍/宠物店','','','8','166','0','0');
INSERT INTO phpmps_category VALUES('167','电脑培训','','','9','167','0','0');
INSERT INTO phpmps_category VALUES('168','外语培训','','','9','168','0','0');
INSERT INTO phpmps_category VALUES('169','学历培训','','','9','169','0','0');
INSERT INTO phpmps_category VALUES('170','婴幼儿教育','','','9','170','0','0');
INSERT INTO phpmps_category VALUES('171','设计培训','','','9','171','0','0');
INSERT INTO phpmps_category VALUES('172','职业技能培训','','','9','172','0','0');
INSERT INTO phpmps_category VALUES('173','艺术/体育/培训','','','9','173','0','0');
INSERT INTO phpmps_category VALUES('174','中小学教育','','','9','174','0','0');
INSERT INTO phpmps_category VALUES('175','全职求职简历','','','10','175','0','0');
INSERT INTO phpmps_category VALUES('176','简直求职简历','','','10','176','0','0');

DROP TABLE IF EXISTS phpmps_com;
CREATE TABLE `phpmps_com` (
  `comid` mediumint(6) unsigned NOT NULL auto_increment,
  `userid` int(11) unsigned NOT NULL,
  `catid` smallint(5) unsigned NOT NULL,
  `areaid` smallint(5) unsigned NOT NULL,
  `comname` varchar(100) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `thumb` varchar(50) NOT NULL,
  `introduce` text,
  `phone` varchar(15) NOT NULL,
  `linkman` varchar(32) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `msn` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `fax` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `hours` varchar(50) NOT NULL,
  `mappoint` varchar(16) NOT NULL,
  `is_check` tinyint(1) unsigned NOT NULL,
  `click` int(11) NOT NULL,
  `postdate` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`comid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_com_cat;
CREATE TABLE `phpmps_com_cat` (
  `catid` mediumint(6) NOT NULL auto_increment,
  `catname` varchar(32) NOT NULL,
  `keywords` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  `parentid` int(11) default NULL,
  `catorder` smallint(6) NOT NULL,
  PRIMARY KEY  (`catid`),
  KEY `parentid` (`parentid`),
  KEY `catname` (`catname`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_com_cat VALUES('1','电脑网络','','','0','1');
INSERT INTO phpmps_com_cat VALUES('2','商业服务','','','0','2');
INSERT INTO phpmps_com_cat VALUES('3','其他行业','','','0','3');

DROP TABLE IF EXISTS phpmps_com_image;
CREATE TABLE `phpmps_com_image` (
  `imgid` int(11) unsigned NOT NULL auto_increment,
  `comid` int(11) unsigned NOT NULL,
  `path` varchar(100) NOT NULL,
  PRIMARY KEY  (`imgid`),
  KEY `infoid` (`comid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_comment;
CREATE TABLE `phpmps_comment` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `infoid` mediumint(8) unsigned NOT NULL default '0',
  `userid` int(11) unsigned NOT NULL,
  `username` varchar(60) NOT NULL,
  `content` text NOT NULL,
  `is_check` tinyint(1) unsigned NOT NULL,
  `postdate` int(10) unsigned NOT NULL default '0',
  `ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `infoid` (`infoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_config;
CREATE TABLE `phpmps_config` (
  `setname` varchar(100) NOT NULL,
  `value` text,
  KEY `setname` (`setname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO phpmps_config VALUES('webname','天水信息网');
INSERT INTO phpmps_config VALUES('weburl','http://192.168.1.8');
INSERT INTO phpmps_config VALUES('keywords','天水生活,天水分类信息，天水房屋租赁，天水信息,天水求职招聘，天水生活信息，天水免费发布查询房屋租售、求职招聘、二手物品、车辆买卖、生活黄页等天水实用信息');
INSERT INTO phpmps_config VALUES('copyright','<font color=\"#ff0000\">求职招聘、房屋租赁、家政服务就上天水信息网</font>');
INSERT INTO phpmps_config VALUES('description','天水信息网为您提供天水分类信息，您可以免费发布和查询求职招聘,房屋出租,二手市场,生活服务等分类信息，天水信息网，天水本土最专业最大的分类信息平台！');
INSERT INTO phpmps_config VALUES('banwords','');
INSERT INTO phpmps_config VALUES('icp','陇ICP备11000291号');
INSERT INTO phpmps_config VALUES('qq','806827154');
INSERT INTO phpmps_config VALUES('post_check','0');
INSERT INTO phpmps_config VALUES('comment_check','0');
INSERT INTO phpmps_config VALUES('count','<script src=\"http://s94.cnzz.com/stat.php?id=2652423&web_id=2652423\" language=\"JavaScript\"></script>');
INSERT INTO phpmps_config VALUES('tplname','default');
INSERT INTO phpmps_config VALUES('crypt','523d4bf7faa7c9fb28ecedab3c0e6665');
INSERT INTO phpmps_config VALUES('maxpost','15');
INSERT INTO phpmps_config VALUES('annouce','<font color=\"#ff0000\">求职招聘、房屋租赁、家政服务就上天水信息网</font>');
INSERT INTO phpmps_config VALUES('rewrite','0');
INSERT INTO phpmps_config VALUES('onlyarea','天水');
INSERT INTO phpmps_config VALUES('map','9839396,4005515');
INSERT INTO phpmps_config VALUES('del_m_info','1');
INSERT INTO phpmps_config VALUES('del_m_comment','1');
INSERT INTO phpmps_config VALUES('pagesize','20');
INSERT INTO phpmps_config VALUES('uc','1');
INSERT INTO phpmps_config VALUES('uc_api','http://localhost/ucenter');
INSERT INTO phpmps_config VALUES('uc_appid','1');
INSERT INTO phpmps_config VALUES('uc_key','phpmps');
INSERT INTO phpmps_config VALUES('uc_dbhost','localhost');
INSERT INTO phpmps_config VALUES('uc_dbname','ucenter');
INSERT INTO phpmps_config VALUES('uc_dbuser','root');
INSERT INTO phpmps_config VALUES('uc_dbpwd','123456');
INSERT INTO phpmps_config VALUES('uc_dbpre','uc_');
INSERT INTO phpmps_config VALUES('uc_charset','gbk');
INSERT INTO phpmps_config VALUES('expired_view','0');
INSERT INTO phpmps_config VALUES('visitor_post','1');
INSERT INTO phpmps_config VALUES('visitor_view','1');
INSERT INTO phpmps_config VALUES('visitor_comment','1');
INSERT INTO phpmps_config VALUES('closesystem','0');
INSERT INTO phpmps_config VALUES('close_tips','网站维护，暂时关闭，请稍后访问。');
INSERT INTO phpmps_config VALUES('postfile','post.php');
INSERT INTO phpmps_config VALUES('sendmailtype','');
INSERT INTO phpmps_config VALUES('smtphost','');
INSERT INTO phpmps_config VALUES('smtpuser','');
INSERT INTO phpmps_config VALUES('smtppass','');
INSERT INTO phpmps_config VALUES('smtpport','');
INSERT INTO phpmps_config VALUES('info_top_gold','1');
INSERT INTO phpmps_config VALUES('info_refer_gold','1');
INSERT INTO phpmps_config VALUES('max_login_credit','2');
INSERT INTO phpmps_config VALUES('register_credit','1');
INSERT INTO phpmps_config VALUES('login_credit','1');
INSERT INTO phpmps_config VALUES('post_info_credit','2');
INSERT INTO phpmps_config VALUES('post_comment_credit','1');
INSERT INTO phpmps_config VALUES('credit2gold','20');
INSERT INTO phpmps_config VALUES('money2gold','1');
INSERT INTO phpmps_config VALUES('max_comment_credit','5');
INSERT INTO phpmps_config VALUES('max_info_credit','5');
INSERT INTO phpmps_config VALUES('qqun','142509126');
INSERT INTO phpmps_config VALUES('phone','15379868686');
INSERT INTO phpmps_config VALUES('email','itbeston@gmail.com');
INSERT INTO phpmps_config VALUES('close_register','0');

DROP TABLE IF EXISTS phpmps_cus_value;
CREATE TABLE `phpmps_cus_value` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `infoid` mediumint(8) unsigned NOT NULL default '0',
  `cusid` smallint(5) unsigned NOT NULL default '0',
  `cusvalue` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `infoid` (`infoid`),
  KEY `cusid` (`cusid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_custom;
CREATE TABLE `phpmps_custom` (
  `cusid` smallint(5) unsigned NOT NULL auto_increment,
  `catid` smallint(5) unsigned NOT NULL default '0',
  `cusname` varchar(60) NOT NULL,
  `custype` tinyint(1) unsigned NOT NULL default '1',
  `value` text NOT NULL,
  `unit` varchar(32) NOT NULL,
  `search` tinyint(1) unsigned NOT NULL default '0',
  `listorder` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`cusid`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_facilitate;
CREATE TABLE `phpmps_facilitate` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `title` varchar(32) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `introduce` varchar(255) NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL,
  `updatetime` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `number` (`phone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_flash;
CREATE TABLE `phpmps_flash` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `image` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL,
  `flaorder` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `image` (`image`),
  KEY `url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_help;
CREATE TABLE `phpmps_help` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `typeid` smallint(5) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `listorder` smallint(5) NOT NULL default '0',
  `addtime` int(11) NOT NULL,
  `is_index` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `is_index` (`is_index`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_help VALUES('1','如何注册成为本站会员','1','如何注册成为本站会员','如何注册成为本站会员','<p><br />\r\n点击网站顶部的注册链接进入填写注册信息页面，填写用户名、密码和邮件,点击注册按钮。</p>\r\n<p>注意： 1. 用户名注册以后是不能更改的&nbsp; 2. 注册用的邮箱是用于密码找回的，所以请尽量填写真实邮箱。</p>','1','1283498679','1');
INSERT INTO phpmps_help VALUES('2','如何登录网站','1','如何登录网站','如何登录网站','<p><br />\r\n点击头部的 [登陆] 链接进入登录页面后,填写用户名和密码进行登录。</p>','2','1283499260','0');
INSERT INTO phpmps_help VALUES('3','如何修改密码','1','如何修改密码','如何修改密码','<p>您可以在个人管理中心中点击【修改密码】的链接进入修改密码页面进行修改。</p>','3','1283499376','0');
INSERT INTO phpmps_help VALUES('4','如何找回密码','1','如何找回密码','如何找回密码','<p><br />\r\n如果您忘记了密码可以使用找回密码操作<br />\r\n<br />\r\n找回密码步骤：<br />\r\n第一步：点击找回密码链接进入填写用户名和邮箱页面。<br />\r\n第二步：填写您注册时输入的用户名和邮箱地址，发送重置密码邮件。<br />\r\n第三步：到邮箱中收信，点击邮件中的&ldquo;重置密码&rdquo;链接，进入重置密码页面<br />\r\n第四步：重新设置您的密码，完成找回密码操作。然后您就可以使用新密码登录了。</p>','4','1283499417','0');
INSERT INTO phpmps_help VALUES('5','如何修改个人资料','1','如何修改个人资料','如何修改个人资料','<p><br />\r\n您可以在个人管理中心中点击&ldquo;修改资料&rdquo;链接进入修改资料页面进行修改。</p>','5','1283499492','1');
INSERT INTO phpmps_help VALUES('6','什么是匿名发布','2','什么是匿名发布','什么是匿名发布','<p>匿名发帖就是不需要登录注册，直接发帖。</p>\r\n<p>匿名发布的信息，唯一的修改凭证就是发布信息时所填写的密码，请牢记这个密码。</p>','6','1283499666','0');
INSERT INTO phpmps_help VALUES('7','如何修改信息内容','2','如何修改信息内容','如何修改信息内容','<p>1.凭密码修改<br />\r\n发布信息的时候会让用户输入一个信息管理密码，您可以在信息详情页输入这个密码进行修改<br />\r\n2.登陆会员中心修改<br />\r\n如果信息是您在登陆状态下发布的，那么您可以登陆会员中心，点击【我的信息】列表，找到具体的信息进行修改，<br />\r\n也可以到信息详情页，点【编辑】进行修改。</p>','7','1283499832','0');
INSERT INTO phpmps_help VALUES('8','什么是一键更新信息','2','什么是一键更新信息','什么是一键更新信息','<p>一键更新信息可以使您的信息自然排在信息的最前端<br />\r\n点击信息详情页的【提升按钮】进行提升，一键更新信息消耗信息币，详情请看<a href=\'member.php?act=credit_rule\'>member.php?act=credit_rule</a></p>','8','1283500716','1');
INSERT INTO phpmps_help VALUES('9','如何置顶信息','2','如何置顶信息','如何置顶信息','<p>发布信息的时候可以选择信息置顶，也可以进入会员中心的信息管理，点击信息右侧的&ldquo;置顶&rdquo;链接进行置顶，信息置顶消耗信息币。</p>','9','1283500968','1');
INSERT INTO phpmps_help VALUES('10','什么是积分，有何用处','3','什么是积分，有何用处','什么是积分，有何用处','<p>积分是对用户注册、登陆、发布信息、发表评论的一种奖励，可以用积分兑换信息币，不用花钱置顶和刷新信息。</p>','10','1283501184','1');
INSERT INTO phpmps_help VALUES('11','什么是信息币','3','什么是信息币','什么是信息币','<p>信息币是本站一种虚拟货币，可以用来对信息进行刷新，置顶。</p>\r\n<p>有两种方式获得信息币，一是用钱购买信息币，二是用积分兑换信息币。</p>','11','1283501243','0');
INSERT INTO phpmps_help VALUES('12','积分、信息比和资金可以转让吗？','3','积分、信息比和资金可以转让吗？','积分、信息比和资金可以转让吗？','<p>均不可以转让，只能供会员自己使用。</p>','12','1283501493','0');

DROP TABLE IF EXISTS phpmps_info;
CREATE TABLE `phpmps_info` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(11) unsigned NOT NULL,
  `catid` mediumint(6) unsigned NOT NULL,
  `areaid` smallint(5) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `thumb` varchar(50) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `linkman` varchar(32) NOT NULL,
  `email` varchar(50) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `mappoint` varchar(20) NOT NULL,
  `postarea` varchar(32) NOT NULL,
  `postdate` int(11) NOT NULL,
  `enddate` int(11) unsigned NOT NULL,
  `ip` varchar(15) NOT NULL,
  `click` smallint(6) unsigned NOT NULL default '0',
  `is_pro` int(11) unsigned NOT NULL,
  `is_top` int(11) unsigned NOT NULL,
  `top_type` tinyint(1) unsigned NOT NULL,
  `is_check` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`),
  KEY `areaid` (`areaid`),
  KEY `postdate` (`postdate`),
  KEY `click` (`click`,`postdate`),
  KEY `is_check` (`is_check`),
  FULLTEXT KEY `keywords` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_info_image;
CREATE TABLE `phpmps_info_image` (
  `imgid` int(11) unsigned NOT NULL auto_increment,
  `infoid` int(11) unsigned NOT NULL,
  `path` varchar(100) NOT NULL,
  PRIMARY KEY  (`imgid`),
  KEY `infoid` (`infoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_link;
CREATE TABLE `phpmps_link` (
  `id` int(11) NOT NULL auto_increment,
  `webname` varchar(30) NOT NULL,
  `url` varchar(50) NOT NULL,
  `linkorder` mediumint(6) NOT NULL,
  `logo` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `webname` (`webname`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_link VALUES('1','天水网','http://www.itianshui.com','1','');
INSERT INTO phpmps_link VALUES('2','天水新闻','http://www.itianshui.com/plus/list.php?tid=3','2','');
INSERT INTO phpmps_link VALUES('3','甘谷新闻网','http://www.itianshui.com/plus/list.php?tid=16','3','');
INSERT INTO phpmps_link VALUES('4','秦州新闻网','http://www.itianshui.com/plus/list.php?tid=17','4','');
INSERT INTO phpmps_link VALUES('5','麦积新闻网','http://www.itianshui.com/plus/list.php?tid=18','5','');
INSERT INTO phpmps_link VALUES('6','秦安新闻网','http://www.itianshui.com/plus/list.php?tid=19','6','');
INSERT INTO phpmps_link VALUES('7','张川新闻网','http://www.itianshui.com/plus/list.php?tid=20','7','');
INSERT INTO phpmps_link VALUES('8','武山新闻网','http://www.itianshui.com/plus/list.php?tid=21','8','');
INSERT INTO phpmps_link VALUES('9','清水新闻网','http://www.itianshui.com/plus/list.php?tid=22','9','');

DROP TABLE IF EXISTS phpmps_member;
CREATE TABLE `phpmps_member` (
  `userid` int(11) unsigned NOT NULL auto_increment,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(32) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(32) NOT NULL,
  `registertime` int(11) unsigned NOT NULL,
  `registerip` varchar(15) NOT NULL,
  `lastlogintime` int(11) unsigned NOT NULL,
  `lastloginip` varchar(15) NOT NULL,
  `sendmailtime` int(11) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `mappoint` varchar(50) NOT NULL,
  `money` float NOT NULL,
  `gold` smallint(5) unsigned NOT NULL,
  `credit` smallint(5) unsigned NOT NULL,
  `lastposttime` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_member VALUES('1','0','demo','dflj@dlfj.com','7fef6171469e80d32c0559f88b377245','1326104214','192.168.1.12','1326104214','192.168.1.12','0','','','','','0','0','1','0');

DROP TABLE IF EXISTS phpmps_nav;
CREATE TABLE `phpmps_nav` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `navname` varchar(32) NOT NULL,
  `url` varchar(100) NOT NULL,
  `target` varchar(6) NOT NULL,
  `navorder` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`navname`),
  KEY `url` (`url`),
  KEY `navorder` (`navorder`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_nav VALUES('1','首页','index.php','_self','1');
INSERT INTO phpmps_nav VALUES('4','教育培训','category.php?id=9','_blank','2');
INSERT INTO phpmps_nav VALUES('5','个人求职','category.php?id=10','_blank','3');
INSERT INTO phpmps_nav VALUES('6','企业招聘','category.php?id=4','_blank','4');
INSERT INTO phpmps_nav VALUES('7','房屋租售','category.php?id=3','_blank','5');
INSERT INTO phpmps_nav VALUES('8','交友活动','category.php?id=6','_blank','6');
INSERT INTO phpmps_nav VALUES('9','物品交易','category.php?id=1','_blank','7');

DROP TABLE IF EXISTS phpmps_pay;
CREATE TABLE `phpmps_pay` (
  `payid` int(11) unsigned NOT NULL auto_increment,
  `typeid` tinyint(3) unsigned NOT NULL default '0',
  `note` char(200) NOT NULL default '',
  `paytype` char(20) NOT NULL default '',
  `amount` float NOT NULL default '0',
  `balance` float NOT NULL default '0',
  `year` smallint(4) unsigned NOT NULL default '0',
  `month` tinyint(2) unsigned NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `username` char(30) NOT NULL default '',
  `ip` char(15) NOT NULL default '',
  `inputer` char(30) NOT NULL default '',
  `inputtime` int(10) unsigned NOT NULL default '0',
  `deleted` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`payid`),
  KEY `type` (`typeid`,`year`,`month`,`date`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_pay_exchange;
CREATE TABLE `phpmps_pay_exchange` (
  `exchangeid` int(11) NOT NULL auto_increment,
  `username` varchar(30) NOT NULL default '',
  `type` enum('money','gold','credit') NOT NULL default 'money',
  `value` float NOT NULL default '0',
  `note` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`exchangeid`),
  KEY `username` (`username`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_pay_exchange VALUES('1','demo','credit','1','register','1326104214','192.168.1.12');

DROP TABLE IF EXISTS phpmps_pay_online;
CREATE TABLE `phpmps_pay_online` (
  `payid` int(11) NOT NULL auto_increment,
  `paycenter` varchar(50) NOT NULL default '',
  `username` varchar(30) NOT NULL default '',
  `orderid` varchar(64) NOT NULL default '',
  `moneytype` varchar(10) NOT NULL default '0',
  `amount` double NOT NULL default '0',
  `trade_fee` double NOT NULL default '0',
  `status` int(11) NOT NULL default '0',
  `contactname` varchar(50) NOT NULL default '',
  `telephone` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `sendtime` int(11) NOT NULL default '0',
  `receivetime` int(11) NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`payid`),
  KEY `username` (`username`,`orderid`,`status`),
  KEY `orderid` (`orderid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_pay_online VALUES('1','alipay','demo','20120109-202020202020-061723','CNY','10','0.1','0','sdf','0991-2394803','phpmps@qq.com','1326104246','0','192.168.1.12');

DROP TABLE IF EXISTS phpmps_payment;
CREATE TABLE `phpmps_payment` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `paycenter` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `sendurl` varchar(100) NOT NULL,
  `receiveurl` varchar(100) NOT NULL,
  `partnerid` varchar(100) NOT NULL,
  `keycode` varchar(100) NOT NULL,
  `percent` float unsigned NOT NULL default '0',
  `email` varchar(60) NOT NULL,
  `enable` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_payment VALUES('1','alipay','支付宝','http://img.alipay.com/img/logo/logo_126x37.gif','http://www.alipay.com/cooperate/gateway.do','http://www.huai114.com/respond.php','202020202020','abcde','1','phpmps@qq.com','1');

DROP TABLE IF EXISTS phpmps_report;
CREATE TABLE `phpmps_report` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `info` int(11) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `ip` varchar(15) NOT NULL,
  `postdate` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_type;
CREATE TABLE `phpmps_type` (
  `typeid` smallint(5) unsigned NOT NULL auto_increment,
  `typename` varchar(32) NOT NULL,
  `listorder` smallint(5) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `module` char(10) NOT NULL,
  PRIMARY KEY  (`typeid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_type VALUES('1','注册与登陆','1','注册与登陆','注册与登陆','help');
INSERT INTO phpmps_type VALUES('2','信息相关','2','信息相关','信息相关','help');
INSERT INTO phpmps_type VALUES('3','积分与信息币相关','3','积分与信息币相关','积分与信息币相关','help');

DROP TABLE IF EXISTS phpmps_ver;
CREATE TABLE `phpmps_ver` (
  `vid` smallint(5) unsigned NOT NULL auto_increment,
  `question` varchar(255) NOT NULL,
  `answer` varchar(50) NOT NULL,
  PRIMARY KEY  (`vid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_ver VALUES('1','35+47=','82');
INSERT INTO phpmps_ver VALUES('2','72-38=','34');
INSERT INTO phpmps_ver VALUES('3','57X4=','228');

