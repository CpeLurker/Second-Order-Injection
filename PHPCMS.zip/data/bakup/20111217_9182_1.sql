# phpmps bakfile
# version:2.2
# time:2011-12-17 05:38:27
# --------------------------------------------------------


DROP TABLE IF EXISTS phpmps_about;
CREATE TABLE `phpmps_about` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `postdate` int(11) NOT NULL,
  `url` varchar(100) NOT NULL,
  `aboutorder` smallint(5) NOT NULL default '0',
  `is_show` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `is_show` (`is_show`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_admin;
CREATE TABLE `phpmps_admin` (
  `userid` smallint(5) unsigned NOT NULL auto_increment,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `truename` varchar(30) NOT NULL,
  `email` varchar(35) NOT NULL,
  `purview` text NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `lastip` varchar(15) NOT NULL,
  `lastlogin` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`userid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_admin VALUES('1','xinxin412','e4846c1b9850bcfe30ff5fe2316e76ae','','admin@hoyaa.cn','','1','127.0.0.1','1324100255');
INSERT INTO phpmps_admin VALUES('2','admin','e4846c1b9850bcfe30ff5fe2316e76ae','','yiyigun@qq.com','config,admin,admin_log,flash,sitemap,nav,area,category,custom,info,comment,report,link,page,fac,ads_place,ads,database,replace,member','0','','0');

DROP TABLE IF EXISTS phpmps_admin_log;
CREATE TABLE `phpmps_admin_log` (
  `logid` int(10) unsigned NOT NULL auto_increment,
  `adminname` varchar(32) NOT NULL,
  `logdate` int(10) unsigned NOT NULL,
  `logtype` varchar(255) NOT NULL,
  `logip` varchar(15) NOT NULL,
  PRIMARY KEY  (`logid`)
) ENGINE=MyISAM AUTO_INCREMENT=253 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_admin_log VALUES('1','xinxin412','1313601192','xinxin412 登陆成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('2','xinxin412','1313601495','修改配制成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('3','xinxin412','1313602554','xinxin412 登陆成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('4','xinxin412','1313602566','插入分类  成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('5','xinxin412','1313602589','插入分类  成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('6','xinxin412','1313602601','插入分类  成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('7','xinxin412','1313602616','删除分类 1 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('8','xinxin412','1313602619','删除分类 2 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('9','xinxin412','1313602627','删除分类 4 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('10','xinxin412','1313602631','删除导航 3 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('11','xinxin412','1313602633','删除导航 2 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('12','xinxin412','1313602671','插入地区 崇川区 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('13','xinxin412','1313602676','插入地区 港闸区 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('14','xinxin412','1313602679','插入地区 开发区 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('15','xinxin412','1313602683','插入地区 通州区 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('16','xinxin412','1313602691','插入地区 启东市 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('17','xinxin412','1313602695','插入地区 海门市 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('18','xinxin412','1313602700','插入地区 如东县 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('19','xinxin412','1313602705','插入地区 如皋市 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('20','xinxin412','1313602708','插入地区 海安县 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('21','xinxin412','1313602712','插入地区 其他地区 成功','117.86.214.96');
INSERT INTO phpmps_admin_log VALUES('22','xinxin412','1313658209','xinxin412 登陆成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('23','xinxin412','1313658223','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('24','xinxin412','1313658246','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('25','xinxin412','1313658258','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('26','xinxin412','1313658272','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('27','xinxin412','1313658281','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('28','xinxin412','1313658290','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('29','xinxin412','1313658305','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('30','xinxin412','1313658319','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('31','xinxin412','1313658326','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('32','xinxin412','1313658340','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('33','xinxin412','1313658373','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('34','xinxin412','1313658382','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('35','xinxin412','1313658393','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('36','xinxin412','1313658416','编辑分类 笔记本/iPad 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('37','xinxin412','1313658427','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('38','xinxin412','1313658438','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('39','xinxin412','1313658447','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('40','xinxin412','1313658458','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('41','xinxin412','1313658469','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('42','xinxin412','1313658478','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('43','xinxin412','1313658488','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('44','xinxin412','1313658518','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('45','xinxin412','1313658530','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('46','xinxin412','1313658542','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('47','xinxin412','1313658552','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('48','xinxin412','1313659503','xinxin412 登陆成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('49','xinxin412','1313659526','添加导航 物品交易 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('50','xinxin412','1313659579','添加导航 车辆买卖 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('51','xinxin412','1313659593','添加导航 房屋租售 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('52','xinxin412','1313659607','添加导航 工作招聘 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('53','xinxin412','1313659627','添加导航 生活服务 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('54','xinxin412','1313659642','添加导航 交友活动 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('55','xinxin412','1313659655','添加导航 兼职实习 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('56','xinxin412','1313659670','添加导航 宠物 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('57','xinxin412','1313659686','添加导航 教育培训 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('58','xinxin412','1313659700','添加导航 求职简历 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('59','xinxin412','1313665149','xinxin412 登陆成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('60','xinxin412','1313665223','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('61','xinxin412','1313665237','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('62','xinxin412','1313665252','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('63','xinxin412','1313665272','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('64','xinxin412','1313665288','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('65','xinxin412','1313665433','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('66','xinxin412','1313665449','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('67','xinxin412','1313665461','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('68','xinxin412','1313665471','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('69','xinxin412','1313665481','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('70','xinxin412','1313665490','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('71','xinxin412','1313665500','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('72','xinxin412','1313665509','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('73','xinxin412','1313665519','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('74','xinxin412','1313665531','xinxin412 登陆成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('75','xinxin412','1313665551','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('76','xinxin412','1313665562','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('77','xinxin412','1313665572','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('78','xinxin412','1313665580','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('79','xinxin412','1313665587','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('80','xinxin412','1313665595','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('81','xinxin412','1313665603','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('82','xinxin412','1313665634','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('83','xinxin412','1313665655','编辑分类 新车 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('84','xinxin412','1313665665','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('85','xinxin412','1313665674','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('86','xinxin412','1313665682','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('87','xinxin412','1313665692','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('88','xinxin412','1313665699','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('89','xinxin412','1313665711','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('90','xinxin412','1313665730','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('91','xinxin412','1313665742','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('92','xinxin412','1313665768','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('93','xinxin412','1313665777','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('94','xinxin412','1313665788','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('95','xinxin412','1313665796','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('96','xinxin412','1313665805','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('97','xinxin412','1313665812','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('98','xinxin412','1313665820','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('99','xinxin412','1313665850','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('100','xinxin412','1313665859','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('101','xinxin412','1313665869','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('102','xinxin412','1313665966','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('103','xinxin412','1313665990','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('104','xinxin412','1313665999','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('105','xinxin412','1313666008','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('106','xinxin412','1313666016','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('107','xinxin412','1313666025','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('108','xinxin412','1313666037','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('109','xinxin412','1313666046','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('110','xinxin412','1313666058','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('111','xinxin412','1313666065','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('112','xinxin412','1313666072','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('113','xinxin412','1313666080','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('114','xinxin412','1313666093','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('115','xinxin412','1313666106','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('116','xinxin412','1313666118','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('117','xinxin412','1313666126','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('118','xinxin412','1313666135','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('119','xinxin412','1313666149','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('120','xinxin412','1313666161','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('121','xinxin412','1313666169','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('122','xinxin412','1313666183','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('123','xinxin412','1313666195','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('124','xinxin412','1313666203','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('125','xinxin412','1313666212','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('126','xinxin412','1313666220','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('127','xinxin412','1313666227','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('128','xinxin412','1313666235','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('129','xinxin412','1313666244','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('130','xinxin412','1313666252','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('131','xinxin412','1313666260','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('132','xinxin412','1313666273','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('133','xinxin412','1313666285','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('134','xinxin412','1313666297','编辑分类 切配 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('135','xinxin412','1313666305','编辑分类 驾校 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('136','xinxin412','1313666319','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('137','xinxin412','1313666340','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('138','xinxin412','1313666348','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('139','xinxin412','1313666358','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('140','xinxin412','1313666367','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('141','xinxin412','1313666378','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('142','xinxin412','1313666386','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('143','xinxin412','1313666396','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('144','xinxin412','1313666418','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('145','xinxin412','1313666426','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('146','xinxin412','1313666439','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('147','xinxin412','1313666464','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('148','xinxin412','1313666481','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('149','xinxin412','1313666498','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('150','xinxin412','1313666511','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('151','xinxin412','1313666520','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('152','xinxin412','1313666543','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('153','xinxin412','1313666551','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('154','xinxin412','1313666558','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('155','xinxin412','1313666566','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('156','xinxin412','1313666578','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('157','xinxin412','1313666603','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('158','xinxin412','1313666611','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('159','xinxin412','1313666619','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('160','xinxin412','1313666626','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('161','xinxin412','1313666636','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('162','xinxin412','1313666644','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('163','xinxin412','1313666652','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('164','xinxin412','1313666664','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('165','xinxin412','1313666672','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('166','xinxin412','1313666681','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('167','xinxin412','1313666689','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('168','xinxin412','1313666699','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('169','xinxin412','1313666733','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('170','xinxin412','1313666742','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('171','xinxin412','1313666771','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('172','xinxin412','1313666780','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('173','xinxin412','1313666789','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('174','xinxin412','1313666799','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('175','xinxin412','1313666807','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('176','xinxin412','1313666815','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('177','xinxin412','1313666823','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('178','xinxin412','1313666834','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('179','xinxin412','1313666845','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('180','xinxin412','1313666853','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('181','xinxin412','1313666865','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('182','xinxin412','1313666892','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('183','xinxin412','1313666912','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('184','xinxin412','1313666921','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('185','xinxin412','1313666929','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('186','xinxin412','1313666942','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('187','xinxin412','1313666949','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('188','xinxin412','1313666957','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('189','xinxin412','1313666967','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('190','xinxin412','1313666975','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('191','xinxin412','1313666983','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('192','xinxin412','1313666991','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('193','xinxin412','1313666998','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('194','xinxin412','1313667007','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('195','xinxin412','1313667014','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('196','xinxin412','1313667027','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('197','xinxin412','1313667037','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('198','xinxin412','1313667046','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('199','xinxin412','1313667057','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('200','xinxin412','1313667067','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('201','xinxin412','1313667075','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('202','xinxin412','1313667082','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('203','xinxin412','1313667091','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('204','xinxin412','1313667100','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('205','xinxin412','1313667116','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('206','xinxin412','1313667125','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('207','xinxin412','1313667133','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('208','xinxin412','1313667140','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('209','xinxin412','1313667147','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('210','xinxin412','1313667155','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('211','xinxin412','1313667167','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('212','xinxin412','1313667175','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('213','xinxin412','1313667184','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('214','xinxin412','1313667194','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('215','xinxin412','1313667207','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('216','xinxin412','1313669899','编辑链接 南通优博网 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('217','xinxin412','1313671237','插入分类  成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('218','xinxin412','1313672102','删除分类 55 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('219','xinxin412','1313674073','修改配制成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('220','xinxin412','1313675947','编辑分类 房屋出租 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('221','xinxin412','1313675968','编辑分类 房屋求租 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('222','xinxin412','1313676004','编辑分类 房屋合租 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('223','xinxin412','1313676030','编辑分类 二手房买卖 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('224','xinxin412','1313676044','编辑分类 新房出售 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('225','xinxin412','1313676068','编辑分类 短租房/日租房 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('226','xinxin412','1313676088','编辑分类 写字楼租售 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('227','xinxin412','1313676109','编辑分类 生意/商铺转让 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('228','xinxin412','1313676183','编辑分类 厂房/仓库/土地 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('229','xinxin412','1313676415','编辑分类 生意/商铺租售 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('230','xinxin412','1313676492','编辑分类 生意/商铺/办公房 成功','180.120.179.190');
INSERT INTO phpmps_admin_log VALUES('231','admin','1324087287','编辑管理员 $username 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('232','admin','1324087793','编辑地区 楚州区 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('233','admin','1324087802','编辑地区 淮阴区 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('234','admin','1324087833','编辑地区 清河区 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('235','admin','1324087842','编辑地区 清浦区 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('236','admin','1324087889','编辑地区 金湖县 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('237','admin','1324087904','编辑地区 盱眙县 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('238','admin','1324087913','编辑地区 涟水县 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('239','admin','1324087926','编辑地区 洪泽县 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('240','admin','1324088235','删除链接 1 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('241','admin','1324088341','修改配制成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('242','admin','1324088422','修改配制成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('243','admin','1324088956','修改配制成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('244','admin','1324089633','添加广告位  成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('245','admin','1324089822','添加广告 160*600 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('246','admin','1324092126','删除记录 3,2,1 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('247','admin','1324092761','添加链接 淮安不孕不育 成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('248','admin','1324092783','修改配制成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('249','','1324100224',' 登陆失败','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('250','','1324100247',' 登陆失败','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('251','xinxin412','1324100255','xinxin412 登陆成功','127.0.0.1');
INSERT INTO phpmps_admin_log VALUES('252','xinxin412','1324100296','添加管理员 $username 成功','127.0.0.1');

DROP TABLE IF EXISTS phpmps_ads;
CREATE TABLE `phpmps_ads` (
  `adsid` smallint(5) unsigned NOT NULL auto_increment,
  `placeid` smallint(5) unsigned NOT NULL,
  `adsname` varchar(32) NOT NULL,
  `adstype` tinyint(3) NOT NULL,
  `adsurl` varchar(150) NOT NULL,
  `adscode` text NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `updatetime` int(11) NOT NULL,
  `linkman` varchar(32) NOT NULL,
  PRIMARY KEY  (`adsid`),
  KEY `adsname` (`adsname`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_ads VALUES('1','1','160*600','4','','<script type=\"text/javascript\"><!--\r\ngoogle_ad_client = \"ca-pub-0857601976390264\";\r\n/* 160x600, 创建于 10-11-5 */\r\ngoogle_ad_slot = \"1902921275\";\r\ngoogle_ad_width = 160;\r\ngoogle_ad_height = 600;\r\n//-->\r\n</script>\r\n<script type=\"text/javascript\"\r\nsrc=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\"> \r\n</script>','1324089822','0','');

DROP TABLE IF EXISTS phpmps_ads_place;
CREATE TABLE `phpmps_ads_place` (
  `placeid` int(11) unsigned NOT NULL auto_increment,
  `placename` varchar(32) NOT NULL,
  `width` smallint(5) unsigned NOT NULL,
  `height` smallint(5) unsigned NOT NULL,
  `introduce` varchar(100) NOT NULL,
  PRIMARY KEY  (`placeid`),
  KEY `placename` (`placename`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_ads_place VALUES('1','内容页','160','600','');

DROP TABLE IF EXISTS phpmps_area;
CREATE TABLE `phpmps_area` (
  `areaid` mediumint(6) NOT NULL auto_increment,
  `areaname` varchar(32) NOT NULL,
  `parentid` int(11) unsigned NOT NULL,
  `areaorder` smallint(6) NOT NULL,
  PRIMARY KEY  (`areaid`),
  KEY `areaname` (`areaname`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_area VALUES('1','楚州区','0','1');
INSERT INTO phpmps_area VALUES('2','淮阴区','0','2');
INSERT INTO phpmps_area VALUES('3','开发区','0','3');
INSERT INTO phpmps_area VALUES('4','清河区','0','4');
INSERT INTO phpmps_area VALUES('5','清浦区','0','5');
INSERT INTO phpmps_area VALUES('6','金湖县','0','6');
INSERT INTO phpmps_area VALUES('7','盱眙县','0','7');
INSERT INTO phpmps_area VALUES('8','涟水县','0','8');
INSERT INTO phpmps_area VALUES('9','洪泽县','0','9');
INSERT INTO phpmps_area VALUES('10','其他地区','0','10');

DROP TABLE IF EXISTS phpmps_article;
CREATE TABLE `phpmps_article` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `typeid` smallint(5) NOT NULL,
  `title` varchar(100) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `thumb` varchar(50) NOT NULL,
  `listorder` smallint(5) NOT NULL default '0',
  `addtime` int(11) NOT NULL,
  `is_index` tinyint(1) unsigned NOT NULL,
  `is_pro` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `is_index` (`is_index`),
  KEY `addtime` (`addtime`),
  KEY `is_pro` (`is_pro`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_category;
CREATE TABLE `phpmps_category` (
  `catid` mediumint(6) NOT NULL auto_increment,
  `catname` varchar(32) NOT NULL,
  `keywords` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  `parentid` int(11) default NULL,
  `catorder` smallint(6) NOT NULL,
  `cattplname` varchar(30) NOT NULL,
  `viewtplname` varchar(30) NOT NULL,
  PRIMARY KEY  (`catid`),
  KEY `parentid` (`parentid`),
  KEY `catname` (`catname`)
) ENGINE=MyISAM AUTO_INCREMENT=178 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_category VALUES('1','物品交易','物品交易','物品交易','0','1','0','0');
INSERT INTO phpmps_category VALUES('2','车辆买卖','车辆买卖','车辆买卖','0','2','0','0');
INSERT INTO phpmps_category VALUES('3','房屋租售','房屋租售','房屋租售','0','3','0','0');
INSERT INTO phpmps_category VALUES('4','工作招聘','工作招聘','工作招聘','0','4','0','0');
INSERT INTO phpmps_category VALUES('5','生活服务','生活服务','生活服务','0','5','0','0');
INSERT INTO phpmps_category VALUES('6','交友活动','交友活动','交友活动','0','6','0','0');
INSERT INTO phpmps_category VALUES('7','兼职实习','兼职实习','兼职实习','0','7','0','0');
INSERT INTO phpmps_category VALUES('8','宠物','宠物','宠物','0','8','0','0');
INSERT INTO phpmps_category VALUES('9','教育培训','教育培训','教育培训','0','9','0','0');
INSERT INTO phpmps_category VALUES('10','求职简历','求职简历','求职简历','0','10','0','0');
INSERT INTO phpmps_category VALUES('11','二手台式电脑','二手台式电脑','二手台式电脑','1','11','0','0');
INSERT INTO phpmps_category VALUES('12','电脑配件/宽带','电脑配件/宽带','电脑配件/宽带','1','12','0','0');
INSERT INTO phpmps_category VALUES('13','笔记本/iPad','笔记本/iPad','笔记本/iPad','1','13','0','0');
INSERT INTO phpmps_category VALUES('14','二手手机','二手手机','二手手机','1','14','0','0');
INSERT INTO phpmps_category VALUES('15','手机号码交易','手机号码交易','手机号码交易','1','15','0','0');
INSERT INTO phpmps_category VALUES('16','照相机/摄像机','照相机/摄像机','照相机/摄像机','1','16','0','0');
INSERT INTO phpmps_category VALUES('17','MP3/游戏机','MP3/游戏机','MP3/游戏机','1','17','0','0');
INSERT INTO phpmps_category VALUES('18','日用品','日用品','日用品','1','18','0','0');
INSERT INTO phpmps_category VALUES('19','食品','食品','食品','1','19','0','0');
INSERT INTO phpmps_category VALUES('20','二手家用电器','二手家用电器','二手家用电器','1','20','0','0');
INSERT INTO phpmps_category VALUES('21','二手家具','二手家具','二手家具','1','21','0','0');
INSERT INTO phpmps_category VALUES('22','办公家具/耗材','办公家具/耗材','办公家具/耗材','1','22','0','0');
INSERT INTO phpmps_category VALUES('23','收藏品/工艺品','收藏品/工艺品','收藏品/工艺品','1','23','0','0');
INSERT INTO phpmps_category VALUES('24','女装/男装','女装/男装','女装/男装','1','24','0','0');
INSERT INTO phpmps_category VALUES('25','配饰/钟表','配饰/钟表','配饰/钟表','1','25','0','0');
INSERT INTO phpmps_category VALUES('26','鞋帽/箱包','鞋帽/箱包','鞋帽/箱包','1','26','0','0');
INSERT INTO phpmps_category VALUES('27','化妆品','化妆品','化妆品','1','27','0','0');
INSERT INTO phpmps_category VALUES('28','母婴/幼儿/玩具','母婴/幼儿/玩具','母婴/幼儿/玩具','1','28','0','0');
INSERT INTO phpmps_category VALUES('29','书报/音像','书报/音像','书报/音像','1','29','0','0');
INSERT INTO phpmps_category VALUES('30','二手乐器/文具','二手乐器/文具','二手乐器/文具','1','30','0','0');
INSERT INTO phpmps_category VALUES('31','二手运动器材','二手运动器材','二手运动器材','1','31','0','0');
INSERT INTO phpmps_category VALUES('32','消费卡/优惠券','消费卡/优惠券','消费卡/优惠券','1','32','0','0');
INSERT INTO phpmps_category VALUES('33','门票/电影票','门票/电影票','门票/电影票','1','33','0','0');
INSERT INTO phpmps_category VALUES('34','火车票/汽车票','火车票/汽车票','火车票/汽车票','1','34','0','0');
INSERT INTO phpmps_category VALUES('35','工业设备','工业设备','工业设备','1','35','0','0');
INSERT INTO phpmps_category VALUES('36','其他转让物品','其他转让物品','其他转让物品','1','36','0','0');
INSERT INTO phpmps_category VALUES('37','物品交换','物品交换','物品交换','1','37','0','0');
INSERT INTO phpmps_category VALUES('38','求购','求购','求购','1','38','0','0');
INSERT INTO phpmps_category VALUES('39','二手车','二手车','二手车','2','39','0','0');
INSERT INTO phpmps_category VALUES('40','汽车用品/配件','汽车用品/配件','汽车用品/配件','2','40','0','0');
INSERT INTO phpmps_category VALUES('41','摩托车/燃气车','摩托车/燃气车','摩托车/燃气车','2','41','0','0');
INSERT INTO phpmps_category VALUES('42','电动车','电动车','电动车','2','42','0','0');
INSERT INTO phpmps_category VALUES('43','自行车','自行车','自行车','2','43','0','0');
INSERT INTO phpmps_category VALUES('44','车辆求购','车辆求购','车辆求购','2','44','0','0');
INSERT INTO phpmps_category VALUES('45','租车','租车','租车','2','45','0','0');
INSERT INTO phpmps_category VALUES('46','新车','新车','新车','2','46','0','0');
INSERT INTO phpmps_category VALUES('47','4S店/经销商','4S店/经销商','4S店/经销商','2','47','0','0');
INSERT INTO phpmps_category VALUES('48','房屋出租','房屋出租','房屋出租','3','48','0','0');
INSERT INTO phpmps_category VALUES('49','房屋求租','房屋求租','房屋求租','3','49','0','0');
INSERT INTO phpmps_category VALUES('50','房屋合租','房屋合租','房屋合租','3','50','0','0');
INSERT INTO phpmps_category VALUES('51','二手房买卖','二手房买卖','二手房买卖','3','51','0','0');
INSERT INTO phpmps_category VALUES('52','新房出售','新房出售','新房出售','3','52','0','0');
INSERT INTO phpmps_category VALUES('53','短租房/日租房','短租房/日租房','短租房/日租房','3','53','0','0');
INSERT INTO phpmps_category VALUES('54','写字楼租售','写字楼租售','写字楼租售','3','54','0','0');
INSERT INTO phpmps_category VALUES('56','生意/商铺/办公房','生意/商铺/办公房','生意/商铺/办公房','3','56','0','0');
INSERT INTO phpmps_category VALUES('57','厂房/仓库/土地','厂房/仓库/土地','厂房/仓库/土地','3','57','0','0');
INSERT INTO phpmps_category VALUES('58','营业员','营业员','营业员','4','58','0','0');
INSERT INTO phpmps_category VALUES('59','店长','店长','店长','4','59','0','0');
INSERT INTO phpmps_category VALUES('60','服务员','服务员','服务员','4','60','0','0');
INSERT INTO phpmps_category VALUES('61','收银员','收银员','收银员','4','61','0','0');
INSERT INTO phpmps_category VALUES('62','销售/业务员','销售/业务员','销售/业务员','4','62','0','0');
INSERT INTO phpmps_category VALUES('63','房地产','房地产','房地产','4','63','0','0');
INSERT INTO phpmps_category VALUES('64','保险','保险','保险','4','64','0','0');
INSERT INTO phpmps_category VALUES('65','文员','文员','文员','4','65','0','0');
INSERT INTO phpmps_category VALUES('66','助理','助理','助理','4','66','0','0');
INSERT INTO phpmps_category VALUES('67','前台','前台','前台','4','67','0','0');
INSERT INTO phpmps_category VALUES('68','行政','行政','行政','4','68','0','0');
INSERT INTO phpmps_category VALUES('69','人事','人事','人事','4','69','0','0');
INSERT INTO phpmps_category VALUES('70','客服','客服','客服','4','70','0','0');
INSERT INTO phpmps_category VALUES('71','市场/运营','市场/运营','市场/运营','4','71','0','0');
INSERT INTO phpmps_category VALUES('72','家政/保洁','家政/保洁','家政/保洁','4','72','0','0');
INSERT INTO phpmps_category VALUES('73','司机','司机','司机','4','73','0','0');
INSERT INTO phpmps_category VALUES('74','保安','保安','保安','4','74','0','0');
INSERT INTO phpmps_category VALUES('75','厨师','厨师','厨师','4','75','0','0');
INSERT INTO phpmps_category VALUES('76','切配','切配','切配','4','76','0','0');
INSERT INTO phpmps_category VALUES('77','送货员','送货员','送货员','4','77','0','0');
INSERT INTO phpmps_category VALUES('78','快递员','快递员','快递员','4','78','0','0');
INSERT INTO phpmps_category VALUES('79','仓管','仓管','仓管','4','79','0','0');
INSERT INTO phpmps_category VALUES('80','网管','网管','网管','4','80','0','0');
INSERT INTO phpmps_category VALUES('81','工人/技工','工人/技工','工人/技工','4','81','0','0');
INSERT INTO phpmps_category VALUES('82','财务/会计/出纳','财务/会计/出纳','财务/会计/出纳','4','82','0','0');
INSERT INTO phpmps_category VALUES('83','IT/互联网','IT/互联网','IT/互联网','4','83','0','0');
INSERT INTO phpmps_category VALUES('84','教育/培训/咨询','教育/培训/咨询','教育/培训/咨询','4','84','0','0');
INSERT INTO phpmps_category VALUES('85','广告/媒体/设计','广告/媒体/设计','广告/媒体/设计','4','85','0','0');
INSERT INTO phpmps_category VALUES('86','建筑/装潢/园林','建筑/装潢/园林','建筑/装潢/园林','4','86','0','0');
INSERT INTO phpmps_category VALUES('87','编辑','编辑','编辑','4','87','0','0');
INSERT INTO phpmps_category VALUES('88','摄影','摄影','摄影','4','88','0','0');
INSERT INTO phpmps_category VALUES('89','翻译','翻译','翻译','4','89','0','0');
INSERT INTO phpmps_category VALUES('90','美容美发','美容美发','美容美发','4','90','0','0');
INSERT INTO phpmps_category VALUES('91','保健按摩','保健按摩','保健按摩','4','91','0','0');
INSERT INTO phpmps_category VALUES('92','招聘会','招聘会','招聘会','4','92','0','0');
INSERT INTO phpmps_category VALUES('93','KTV/酒吧','KTV/酒吧','KTV/酒吧','4','93','0','0');
INSERT INTO phpmps_category VALUES('94','其他招聘','其他招聘','其他招聘','4','94','0','0');
INSERT INTO phpmps_category VALUES('95','租车','租车','租车','5','95','0','0');
INSERT INTO phpmps_category VALUES('96','驾校','驾校','驾校','5','96','0','0');
INSERT INTO phpmps_category VALUES('97','陪驾/代驾','陪驾/代驾','陪驾/代驾','5','97','0','0');
INSERT INTO phpmps_category VALUES('98','汽车检修/保养','汽车检修/保养','汽车检修/保养','5','98','0','0');
INSERT INTO phpmps_category VALUES('99','家政保姆服务','家政保姆服务','家政保姆服务','5','99','0','0');
INSERT INTO phpmps_category VALUES('100','保洁清洗服务','保洁清洗服务','保洁清洗服务','5','100','0','0');
INSERT INTO phpmps_category VALUES('101','装修','装修','装修','5','101','0','0');
INSERT INTO phpmps_category VALUES('102','疏通','疏通','疏通','5','102','0','0');
INSERT INTO phpmps_category VALUES('103','建材装饰','建材装饰','建材装饰','5','103','0','0');
INSERT INTO phpmps_category VALUES('104','家居维修','家居维修','家居维修','5','104','0','0');
INSERT INTO phpmps_category VALUES('105','搬家','搬家','搬家','5','105','0','0');
INSERT INTO phpmps_category VALUES('106','快递/物流','快递/物流','快递/物流','5','106','0','0');
INSERT INTO phpmps_category VALUES('107','电脑维修','电脑维修','电脑维修','5','107','0','0');
INSERT INTO phpmps_category VALUES('108','家电维修','家电维修','家电维修','5','108','0','0');
INSERT INTO phpmps_category VALUES('109','招商加盟/代理','招商加盟/代理','招商加盟/代理','5','109','0','0');
INSERT INTO phpmps_category VALUES('110','公司注册/年检','公司注册/年检','公司注册/年检','5','110','0','0');
INSERT INTO phpmps_category VALUES('111','担保/贷款','担保/贷款','担保/贷款','5','111','0','0');
INSERT INTO phpmps_category VALUES('112','投资理财/保险','投资理财/保险','投资理财/保险','5','112','0','0');
INSERT INTO phpmps_category VALUES('113','会计/审计/评估','会计/审计/评估','会计/审计/评估','5','113','0','0');
INSERT INTO phpmps_category VALUES('114','旅游','旅游','旅游','5','114','0','0');
INSERT INTO phpmps_category VALUES('115','酒店','酒店','酒店','5','115','0','0');
INSERT INTO phpmps_category VALUES('116','机票/签证','机票/签证','机票/签证','5','116','0','0');
INSERT INTO phpmps_category VALUES('117','网站建设/推广','网站建设/推广','网站建设/推广','5','117','0','0');
INSERT INTO phpmps_category VALUES('118','鲜花','鲜花','鲜花','5','118','0','0');
INSERT INTO phpmps_category VALUES('119','礼品/定制','礼品/定制','礼品/定制','5','119','0','0');
INSERT INTO phpmps_category VALUES('120','美容纤体','美容纤体','美容纤体','5','120','0','0');
INSERT INTO phpmps_category VALUES('121','婚庆/化妆/司仪','婚庆/化妆/司仪','','5','121','0','0');
INSERT INTO phpmps_category VALUES('122','摄影服务','摄影服务','摄影服务','5','122','0','0');
INSERT INTO phpmps_category VALUES('123','设计策划','设计策划','设计策划','5','123','0','0');
INSERT INTO phpmps_category VALUES('124','印刷/喷绘招牌','印刷/喷绘招牌','印刷/喷绘招牌','5','124','0','0');
INSERT INTO phpmps_category VALUES('125','翻译','翻译','翻译','5','125','0','0');
INSERT INTO phpmps_category VALUES('126','律师','律师','律师','5','126','0','0');
INSERT INTO phpmps_category VALUES('127','物品/设备租赁','物品/设备租赁','物品/设备租赁','5','127','0','0');
INSERT INTO phpmps_category VALUES('128','物品回收','物品回收','物品回收','5','128','0','0');
INSERT INTO phpmps_category VALUES('129','其他服务','其他服务','其他服务','5','129','0','0');
INSERT INTO phpmps_category VALUES('130','男士征婚','男士征婚','男士征婚','6','130','0','0');
INSERT INTO phpmps_category VALUES('131','女士征婚','女士征婚','女士征婚','6','131','0','0');
INSERT INTO phpmps_category VALUES('132','找男朋友','找男朋友','找男朋友','6','132','0','0');
INSERT INTO phpmps_category VALUES('133','找女朋友','找女朋友','找女朋友','6','133','0','0');
INSERT INTO phpmps_category VALUES('134','拼车顺风车','拼车顺风车','拼车顺风车','6','134','0','0');
INSERT INTO phpmps_category VALUES('135','同城聚会','同城聚会','同城聚会','6','135','0','0');
INSERT INTO phpmps_category VALUES('136','运动打球','运动打球','运动打球','6','136','0','0');
INSERT INTO phpmps_category VALUES('137','结伴出游','结伴出游','结伴出游','6','137','0','0');
INSERT INTO phpmps_category VALUES('138','技能交换','技能交换','技能交换','5','138','0','0');
INSERT INTO phpmps_category VALUES('139','寻人/寻物','寻人/寻物','寻人/寻物','6','139','0','0');
INSERT INTO phpmps_category VALUES('140','同乡会','同乡会','同乡会','6','140','0','0');
INSERT INTO phpmps_category VALUES('141','同学会','同学会','同学会','6','141','0','0');
INSERT INTO phpmps_category VALUES('142','兴趣交友','兴趣交友','兴趣交友','6','142','0','0');
INSERT INTO phpmps_category VALUES('143','真情告白/祝福','真情告白/祝福','真情告白/祝福','6','143','0','0');
INSERT INTO phpmps_category VALUES('144','家教','家教','家教','7','144','0','0');
INSERT INTO phpmps_category VALUES('145','会计','会计','会计','7','145','0','0');
INSERT INTO phpmps_category VALUES('146','模特','模特','模特','7','146','0','0');
INSERT INTO phpmps_category VALUES('147','礼仪','礼仪','礼仪','7','147','0','0');
INSERT INTO phpmps_category VALUES('148','设计','设计','设计','7','148','0','0');
INSERT INTO phpmps_category VALUES('149','网站','网站','网站','7','149','0','0');
INSERT INTO phpmps_category VALUES('150','摄影','摄影','摄影','7','150','0','0');
INSERT INTO phpmps_category VALUES('151','演员','演员','演员','7','151','0','0');
INSERT INTO phpmps_category VALUES('152','翻译','翻译','翻译','7','152','0','0');
INSERT INTO phpmps_category VALUES('153','客服','客服','客服','7','153','0','0');
INSERT INTO phpmps_category VALUES('154','其他兼职','其他兼职','其他兼职','7','154','0','0');
INSERT INTO phpmps_category VALUES('155','实习生','实习生','实习生','7','155','0','0');
INSERT INTO phpmps_category VALUES('156','销售','销售','销售','7','156','0','0');
INSERT INTO phpmps_category VALUES('157','派发','派发','派发','7','157','0','0');
INSERT INTO phpmps_category VALUES('158','促销','促销','促销','7','158','0','0');
INSERT INTO phpmps_category VALUES('159','临时工/小时工','临时工/小时工','临时工/小时工','7','159','0','0');
INSERT INTO phpmps_category VALUES('160','充场/座谈会','充场/座谈会','充场/座谈会','7','160','0','0');
INSERT INTO phpmps_category VALUES('161','宠物狗','宠物狗','宠物狗','8','161','0','0');
INSERT INTO phpmps_category VALUES('162','猫/其他宠物','猫/其他宠物','猫/其他宠物','8','162','0','0');
INSERT INTO phpmps_category VALUES('163','宠物免费赠送','宠物免费赠送','宠物免费赠送','8','163','0','0');
INSERT INTO phpmps_category VALUES('164','宠物用品/食品','宠物用品/食品','宠物用品/食品','8','164','0','0');
INSERT INTO phpmps_category VALUES('165','宠物服务/配种','宠物服务/配种','宠物服务/配种','8','165','0','0');
INSERT INTO phpmps_category VALUES('166','犬舍/宠物店','犬舍/宠物店','犬舍/宠物店','8','166','0','0');
INSERT INTO phpmps_category VALUES('167','电脑培训','电脑培训','电脑培训','9','167','0','0');
INSERT INTO phpmps_category VALUES('168','外语培训','外语培训','外语培训','9','168','0','0');
INSERT INTO phpmps_category VALUES('169','学历教育','学历教育','学历教育','9','169','0','0');
INSERT INTO phpmps_category VALUES('170','婴幼儿教育','婴幼儿教育','婴幼儿教育','9','170','0','0');
INSERT INTO phpmps_category VALUES('171','设计培训','设计培训','设计培训','9','171','0','0');
INSERT INTO phpmps_category VALUES('172','职业技能培训','职业技能培训','职业技能培训','9','172','0','0');
INSERT INTO phpmps_category VALUES('173','文艺/体育培训','文艺/体育培训','文艺/体育培训','9','173','0','0');
INSERT INTO phpmps_category VALUES('174','中小学教育','中小学教育','中小学教育','9','174','0','0');
INSERT INTO phpmps_category VALUES('175','全职求职简历','全职求职简历','全职求职简历','10','175','0','0');
INSERT INTO phpmps_category VALUES('176','兼职求职简历','兼职求职简历','兼职求职简历','10','176','0','0');
INSERT INTO phpmps_category VALUES('177','陪驾/代驾','陪驾/代驾','陪驾/代驾','2','177','0','0');

DROP TABLE IF EXISTS phpmps_com;
CREATE TABLE `phpmps_com` (
  `comid` mediumint(6) unsigned NOT NULL auto_increment,
  `userid` int(11) unsigned NOT NULL,
  `catid` smallint(5) unsigned NOT NULL,
  `areaid` smallint(5) unsigned NOT NULL,
  `comname` varchar(100) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `thumb` varchar(50) NOT NULL,
  `introduce` text,
  `phone` varchar(15) NOT NULL,
  `linkman` varchar(32) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `msn` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `fax` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `hours` varchar(50) NOT NULL,
  `mappoint` varchar(16) NOT NULL,
  `is_check` tinyint(1) unsigned NOT NULL,
  `click` int(11) NOT NULL,
  `postdate` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`comid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_com_cat;
CREATE TABLE `phpmps_com_cat` (
  `catid` mediumint(6) NOT NULL auto_increment,
  `catname` varchar(32) NOT NULL,
  `keywords` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  `parentid` int(11) default NULL,
  `catorder` smallint(6) NOT NULL,
  PRIMARY KEY  (`catid`),
  KEY `parentid` (`parentid`),
  KEY `catname` (`catname`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_com_image;
CREATE TABLE `phpmps_com_image` (
  `imgid` int(11) unsigned NOT NULL auto_increment,
  `comid` int(11) unsigned NOT NULL,
  `path` varchar(100) NOT NULL,
  PRIMARY KEY  (`imgid`),
  KEY `infoid` (`comid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_comment;
CREATE TABLE `phpmps_comment` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `infoid` mediumint(8) unsigned NOT NULL default '0',
  `userid` int(11) unsigned NOT NULL,
  `username` varchar(60) NOT NULL,
  `content` text NOT NULL,
  `is_check` tinyint(1) unsigned NOT NULL,
  `postdate` int(10) unsigned NOT NULL default '0',
  `ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `infoid` (`infoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_config;
CREATE TABLE `phpmps_config` (
  `setname` varchar(100) NOT NULL,
  `value` text,
  KEY `setname` (`setname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO phpmps_config VALUES('webname','【淮安百事通】 -免费发布信息-淮安分类信息门户');
INSERT INTO phpmps_config VALUES('weburl','http://www.huai114.com');
INSERT INTO phpmps_config VALUES('keywords','南通,南通分类信息,南通生活信息,南通百有网');
INSERT INTO phpmps_config VALUES('copyright','淮安百事通 知百事 赢天下！');
INSERT INTO phpmps_config VALUES('description','在淮安百事通，您可以免费查找淮安最新最全的二手物品交易、二手车买卖、房屋租售、宠物、招聘、兼职、求职、交友活动、生活服务信息。还能免费发布这些信息。');
INSERT INTO phpmps_config VALUES('banwords','');
INSERT INTO phpmps_config VALUES('icp','');
INSERT INTO phpmps_config VALUES('qq','296490257');
INSERT INTO phpmps_config VALUES('post_check','0');
INSERT INTO phpmps_config VALUES('comment_check','0');
INSERT INTO phpmps_config VALUES('count','');
INSERT INTO phpmps_config VALUES('tplname','baiuo');
INSERT INTO phpmps_config VALUES('crypt','2479f43883ae55e982b782af7dbaab1c');
INSERT INTO phpmps_config VALUES('maxpost','15');
INSERT INTO phpmps_config VALUES('annouce','');
INSERT INTO phpmps_config VALUES('rewrite','0');
INSERT INTO phpmps_config VALUES('onlyarea','');
INSERT INTO phpmps_config VALUES('map','');
INSERT INTO phpmps_config VALUES('del_m_info','1');
INSERT INTO phpmps_config VALUES('del_m_comment','1');
INSERT INTO phpmps_config VALUES('pagesize','20');
INSERT INTO phpmps_config VALUES('uc','0');
INSERT INTO phpmps_config VALUES('uc_api','http://localhost/ucenter');
INSERT INTO phpmps_config VALUES('uc_appid','1');
INSERT INTO phpmps_config VALUES('uc_key','phpmps');
INSERT INTO phpmps_config VALUES('uc_dbhost','localhost');
INSERT INTO phpmps_config VALUES('uc_dbname','ucenter');
INSERT INTO phpmps_config VALUES('uc_dbuser','root');
INSERT INTO phpmps_config VALUES('uc_dbpwd','');
INSERT INTO phpmps_config VALUES('uc_dbpre','uc_');
INSERT INTO phpmps_config VALUES('uc_charset','gbk');
INSERT INTO phpmps_config VALUES('expired_view','0');
INSERT INTO phpmps_config VALUES('visitor_post','1');
INSERT INTO phpmps_config VALUES('visitor_view','1');
INSERT INTO phpmps_config VALUES('visitor_comment','1');
INSERT INTO phpmps_config VALUES('closesystem','0');
INSERT INTO phpmps_config VALUES('close_tips','网站维护，暂时关闭，请稍后访问。');
INSERT INTO phpmps_config VALUES('postfile','post.php');
INSERT INTO phpmps_config VALUES('sendmailtype','smtp');
INSERT INTO phpmps_config VALUES('smtphost','mail.huai114.com');
INSERT INTO phpmps_config VALUES('smtpuser','info@huai114.com');
INSERT INTO phpmps_config VALUES('smtppass','112233yejian');
INSERT INTO phpmps_config VALUES('smtpport','25');
INSERT INTO phpmps_config VALUES('info_top_gold','1');
INSERT INTO phpmps_config VALUES('info_refer_gold','1');
INSERT INTO phpmps_config VALUES('max_login_credit','2');
INSERT INTO phpmps_config VALUES('register_credit','1');
INSERT INTO phpmps_config VALUES('login_credit','1');
INSERT INTO phpmps_config VALUES('post_info_credit','2');
INSERT INTO phpmps_config VALUES('post_comment_credit','1');
INSERT INTO phpmps_config VALUES('credit2gold','20');
INSERT INTO phpmps_config VALUES('money2gold','1');
INSERT INTO phpmps_config VALUES('max_comment_credit','5');
INSERT INTO phpmps_config VALUES('max_info_credit','5');
INSERT INTO phpmps_config VALUES('qqun','');
INSERT INTO phpmps_config VALUES('phone','15052611371');
INSERT INTO phpmps_config VALUES('email','info@huai114.com');
INSERT INTO phpmps_config VALUES('close_register','0');

DROP TABLE IF EXISTS phpmps_cus_value;
CREATE TABLE `phpmps_cus_value` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `infoid` mediumint(8) unsigned NOT NULL default '0',
  `cusid` smallint(5) unsigned NOT NULL default '0',
  `cusvalue` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `infoid` (`infoid`),
  KEY `cusid` (`cusid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_custom;
CREATE TABLE `phpmps_custom` (
  `cusid` smallint(5) unsigned NOT NULL auto_increment,
  `catid` smallint(5) unsigned NOT NULL default '0',
  `cusname` varchar(60) NOT NULL,
  `custype` tinyint(1) unsigned NOT NULL default '1',
  `value` text NOT NULL,
  `unit` varchar(32) NOT NULL,
  `search` tinyint(1) unsigned NOT NULL default '0',
  `listorder` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`cusid`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_facilitate;
CREATE TABLE `phpmps_facilitate` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `title` varchar(32) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `introduce` varchar(255) NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL,
  `updatetime` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `number` (`phone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_flash;
CREATE TABLE `phpmps_flash` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `image` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL,
  `flaorder` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `image` (`image`),
  KEY `url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_help;
CREATE TABLE `phpmps_help` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `typeid` smallint(5) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `listorder` smallint(5) NOT NULL default '0',
  `addtime` int(11) NOT NULL,
  `is_index` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `is_index` (`is_index`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_help VALUES('1','如何注册成为本站会员','1','如何注册成为本站会员','如何注册成为本站会员','<p><br />\r\n点击网站顶部的注册链接进入填写注册信息页面，填写用户名、密码和邮件,点击注册按钮。</p>\r\n<p>注意： 1. 用户名注册以后是不能更改的&nbsp; 2. 注册用的邮箱是用于密码找回的，所以请尽量填写真实邮箱。</p>','1','1283498679','1');
INSERT INTO phpmps_help VALUES('2','如何登录网站','1','如何登录网站','如何登录网站','<p><br />\r\n点击头部的 [登陆] 链接进入登录页面后,填写用户名和密码进行登录。</p>','2','1283499260','0');
INSERT INTO phpmps_help VALUES('3','如何修改密码','1','如何修改密码','如何修改密码','<p>您可以在个人管理中心中点击【修改密码】的链接进入修改密码页面进行修改。</p>','3','1283499376','0');
INSERT INTO phpmps_help VALUES('4','如何找回密码','1','如何找回密码','如何找回密码','<p><br />\r\n如果您忘记了密码可以使用找回密码操作<br />\r\n<br />\r\n找回密码步骤：<br />\r\n第一步：点击找回密码链接进入填写用户名和邮箱页面。<br />\r\n第二步：填写您注册时输入的用户名和邮箱地址，发送重置密码邮件。<br />\r\n第三步：到邮箱中收信，点击邮件中的&ldquo;重置密码&rdquo;链接，进入重置密码页面<br />\r\n第四步：重新设置您的密码，完成找回密码操作。然后您就可以使用新密码登录了。</p>','4','1283499417','0');
INSERT INTO phpmps_help VALUES('5','如何修改个人资料','1','如何修改个人资料','如何修改个人资料','<p><br />\r\n您可以在个人管理中心中点击&ldquo;修改资料&rdquo;链接进入修改资料页面进行修改。</p>','5','1283499492','1');
INSERT INTO phpmps_help VALUES('6','什么是匿名发布','2','什么是匿名发布','什么是匿名发布','<p>匿名发帖就是不需要登录注册，直接发帖。</p>\r\n<p>匿名发布的信息，唯一的修改凭证就是发布信息时所填写的密码，请牢记这个密码。</p>','6','1283499666','0');
INSERT INTO phpmps_help VALUES('7','如何修改信息内容','2','如何修改信息内容','如何修改信息内容','<p>1.凭密码修改<br />\r\n发布信息的时候会让用户输入一个信息管理密码，您可以在信息详情页输入这个密码进行修改<br />\r\n2.登陆会员中心修改<br />\r\n如果信息是您在登陆状态下发布的，那么您可以登陆会员中心，点击【我的信息】列表，找到具体的信息进行修改，<br />\r\n也可以到信息详情页，点【编辑】进行修改。</p>','7','1283499832','0');
INSERT INTO phpmps_help VALUES('8','什么是一键更新信息','2','什么是一键更新信息','什么是一键更新信息','<p>一键更新信息可以使您的信息自然排在信息的最前端<br />\r\n点击信息详情页的【提升按钮】进行提升，一键更新信息消耗信息币，详情请看<a href=\'member.php?act=credit_rule\'>member.php?act=credit_rule</a></p>','8','1283500716','1');
INSERT INTO phpmps_help VALUES('9','如何置顶信息','2','如何置顶信息','如何置顶信息','<p>发布信息的时候可以选择信息置顶，也可以进入会员中心的信息管理，点击信息右侧的&ldquo;置顶&rdquo;链接进行置顶，信息置顶消耗信息币。</p>','9','1283500968','1');
INSERT INTO phpmps_help VALUES('10','什么是积分，有何用处','3','什么是积分，有何用处','什么是积分，有何用处','<p>积分是对用户注册、登陆、发布信息、发表评论的一种奖励，可以用积分兑换信息币，不用花钱置顶和刷新信息。</p>','10','1283501184','1');
INSERT INTO phpmps_help VALUES('11','什么是信息币','3','什么是信息币','什么是信息币','<p>信息币是本站一种虚拟货币，可以用来对信息进行刷新，置顶。</p>\r\n<p>有两种方式获得信息币，一是用钱购买信息币，二是用积分兑换信息币。</p>','11','1283501243','0');
INSERT INTO phpmps_help VALUES('12','积分、信息比和资金可以转让吗？','3','积分、信息比和资金可以转让吗？','积分、信息比和资金可以转让吗？','<p>均不可以转让，只能供会员自己使用。</p>','12','1283501493','0');

DROP TABLE IF EXISTS phpmps_info;
CREATE TABLE `phpmps_info` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `userid` int(11) unsigned NOT NULL,
  `catid` mediumint(6) unsigned NOT NULL,
  `areaid` smallint(5) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `thumb` varchar(50) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `linkman` varchar(32) NOT NULL,
  `email` varchar(50) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `mappoint` varchar(20) NOT NULL,
  `postarea` varchar(32) NOT NULL,
  `postdate` int(11) NOT NULL,
  `enddate` int(11) unsigned NOT NULL,
  `ip` varchar(15) NOT NULL,
  `click` smallint(6) unsigned NOT NULL default '0',
  `is_pro` int(11) unsigned NOT NULL,
  `is_top` int(11) unsigned NOT NULL,
  `top_type` tinyint(1) unsigned NOT NULL,
  `is_check` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`),
  KEY `areaid` (`areaid`),
  KEY `postdate` (`postdate`),
  KEY `click` (`click`,`postdate`),
  KEY `is_check` (`is_check`),
  FULLTEXT KEY `keywords` (`keywords`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_info_image;
CREATE TABLE `phpmps_info_image` (
  `imgid` int(11) unsigned NOT NULL auto_increment,
  `infoid` int(11) unsigned NOT NULL,
  `path` varchar(100) NOT NULL,
  PRIMARY KEY  (`imgid`),
  KEY `infoid` (`infoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_link;
CREATE TABLE `phpmps_link` (
  `id` int(11) NOT NULL auto_increment,
  `webname` varchar(30) NOT NULL,
  `url` varchar(50) NOT NULL,
  `linkorder` mediumint(6) NOT NULL,
  `logo` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `webname` (`webname`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_link VALUES('2','淮安不孕不育','http://www.harayy.com/byby','1','');

DROP TABLE IF EXISTS phpmps_member;
CREATE TABLE `phpmps_member` (
  `userid` int(11) unsigned NOT NULL auto_increment,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(32) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(32) NOT NULL,
  `registertime` int(11) unsigned NOT NULL,
  `registerip` varchar(15) NOT NULL,
  `lastlogintime` int(11) unsigned NOT NULL,
  `lastloginip` varchar(15) NOT NULL,
  `sendmailtime` int(11) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `mappoint` varchar(50) NOT NULL,
  `money` float NOT NULL,
  `gold` smallint(5) unsigned NOT NULL,
  `credit` smallint(5) unsigned NOT NULL,
  `lastposttime` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_member VALUES('1','0','叶健','yiyigun@qq.com','e4846c1b9850bcfe30ff5fe2316e76ae','1324089481','127.0.0.1','1324089481','127.0.0.1','0','296490257','15052611371','淮安市博爱医院','','0','0','1','0');

DROP TABLE IF EXISTS phpmps_nav;
CREATE TABLE `phpmps_nav` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `navname` varchar(32) NOT NULL,
  `url` varchar(100) NOT NULL,
  `target` varchar(6) NOT NULL,
  `navorder` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`navname`),
  KEY `url` (`url`),
  KEY `navorder` (`navorder`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_nav VALUES('1','首页','index.php','_self','1');
INSERT INTO phpmps_nav VALUES('4','物品交易','category.php?id=1','_self','2');
INSERT INTO phpmps_nav VALUES('5','车辆买卖','category.php?id=2','_self','3');
INSERT INTO phpmps_nav VALUES('6','房屋租售','category.php?id=3','_self','4');
INSERT INTO phpmps_nav VALUES('7','工作招聘','category.php?id=4','_self','5');
INSERT INTO phpmps_nav VALUES('8','生活服务','category.php?id=5','_self','6');
INSERT INTO phpmps_nav VALUES('9','交友活动','category.php?id=6','_self','7');
INSERT INTO phpmps_nav VALUES('10','兼职实习','category.php?id=7','_self','8');
INSERT INTO phpmps_nav VALUES('11','宠物','category.php?id=8','_self','9');
INSERT INTO phpmps_nav VALUES('12','教育培训','category.php?id=9','_self','10');
INSERT INTO phpmps_nav VALUES('13','求职简历','category.php?id=10','_self','11');

DROP TABLE IF EXISTS phpmps_pay;
CREATE TABLE `phpmps_pay` (
  `payid` int(11) unsigned NOT NULL auto_increment,
  `typeid` tinyint(3) unsigned NOT NULL default '0',
  `note` char(200) NOT NULL default '',
  `paytype` char(20) NOT NULL default '',
  `amount` float NOT NULL default '0',
  `balance` float NOT NULL default '0',
  `year` smallint(4) unsigned NOT NULL default '0',
  `month` tinyint(2) unsigned NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `username` char(30) NOT NULL default '',
  `ip` char(15) NOT NULL default '',
  `inputer` char(30) NOT NULL default '',
  `inputtime` int(10) unsigned NOT NULL default '0',
  `deleted` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`payid`),
  KEY `type` (`typeid`,`year`,`month`,`date`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_pay_exchange;
CREATE TABLE `phpmps_pay_exchange` (
  `exchangeid` int(11) NOT NULL auto_increment,
  `username` varchar(30) NOT NULL default '',
  `type` enum('money','gold','credit') NOT NULL default 'money',
  `value` float NOT NULL default '0',
  `note` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`exchangeid`),
  KEY `username` (`username`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_pay_exchange VALUES('1','叶健','credit','1','register','1324089481','127.0.0.1');

DROP TABLE IF EXISTS phpmps_pay_online;
CREATE TABLE `phpmps_pay_online` (
  `payid` int(11) NOT NULL auto_increment,
  `paycenter` varchar(50) NOT NULL default '',
  `username` varchar(30) NOT NULL default '',
  `orderid` varchar(64) NOT NULL default '',
  `moneytype` varchar(10) NOT NULL default '0',
  `amount` double NOT NULL default '0',
  `trade_fee` double NOT NULL default '0',
  `status` int(11) NOT NULL default '0',
  `contactname` varchar(50) NOT NULL default '',
  `telephone` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `sendtime` int(11) NOT NULL default '0',
  `receivetime` int(11) NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`payid`),
  KEY `username` (`username`,`orderid`,`status`),
  KEY `orderid` (`orderid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_payment;
CREATE TABLE `phpmps_payment` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `paycenter` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `sendurl` varchar(100) NOT NULL,
  `receiveurl` varchar(100) NOT NULL,
  `partnerid` varchar(100) NOT NULL,
  `keycode` varchar(100) NOT NULL,
  `percent` float unsigned NOT NULL default '0',
  `email` varchar(60) NOT NULL,
  `enable` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_payment VALUES('1','alipay','支付宝','http://img.alipay.com/img/logo/logo_126x37.gif','http://www.alipay.com/cooperate/gateway.do','http://www.huai114.com/respond.php','202020202020','abcde','1','phpmps@qq.com','0');

DROP TABLE IF EXISTS phpmps_report;
CREATE TABLE `phpmps_report` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `info` int(11) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `ip` varchar(15) NOT NULL,
  `postdate` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS phpmps_type;
CREATE TABLE `phpmps_type` (
  `typeid` smallint(5) unsigned NOT NULL auto_increment,
  `typename` varchar(32) NOT NULL,
  `listorder` smallint(5) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `module` char(10) NOT NULL,
  PRIMARY KEY  (`typeid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_type VALUES('1','注册与登陆','1','注册与登陆','注册与登陆','help');
INSERT INTO phpmps_type VALUES('2','信息相关','2','信息相关','信息相关','help');
INSERT INTO phpmps_type VALUES('3','积分与信息币相关','3','积分与信息币相关','积分与信息币相关','help');

DROP TABLE IF EXISTS phpmps_ver;
CREATE TABLE `phpmps_ver` (
  `vid` smallint(5) unsigned NOT NULL auto_increment,
  `question` varchar(255) NOT NULL,
  `answer` varchar(50) NOT NULL,
  PRIMARY KEY  (`vid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO phpmps_ver VALUES('1','开国总理是谁(周恩来)','周恩来');
INSERT INTO phpmps_ver VALUES('2','淮安全市的邮编(223000)','223000');
INSERT INTO phpmps_ver VALUES('3','淮安的区号是(0517)','0517');

