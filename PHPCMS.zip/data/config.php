<?php
$db_host   = "localhost";

$db_name   = "phpmps";

$db_user   = "root";

$db_pass   = "123456";

$table     = "phpmps_";

$charset   = "utf-8";

$dbcharset = "utf8";
?>