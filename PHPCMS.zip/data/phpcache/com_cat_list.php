<?php
$data = array (
  1 => 
  array (
    'catid' => '1',
    'catname' => '电脑网络',
    'caturl' => 'com.php?act=list&catid=1',
  ),
  2 => 
  array (
    'catid' => '2',
    'catname' => '商业服务',
    'caturl' => 'com.php?act=list&catid=2',
  ),
  3 => 
  array (
    'catid' => '3',
    'catname' => '其他行业',
    'caturl' => 'com.php?act=list&catid=3',
  ),
);
?>