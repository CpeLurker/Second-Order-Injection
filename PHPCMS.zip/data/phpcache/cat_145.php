<?php
$data = array (
  'catid' => '145',
  'catname' => '会计',
  'keywords' => '',
  'description' => '',
  'parentid' => '7',
  'catorder' => '145',
  'cattplname' => '0',
  'viewtplname' => '0',
);
?>