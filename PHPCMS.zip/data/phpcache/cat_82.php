<?php
$data = array (
  'catid' => '82',
  'catname' => '招聘财务/会计出纳',
  'keywords' => '',
  'description' => '',
  'parentid' => '4',
  'catorder' => '82',
  'cattplname' => '0',
  'viewtplname' => '0',
);
?>