<?php
$data = array (
  1 => 
  array (
    'vid' => '1',
    'question' => '35+47=',
    'answer' => '82',
  ),
  2 => 
  array (
    'vid' => '2',
    'question' => '72-38=',
    'answer' => '34',
  ),
  3 => 
  array (
    'vid' => '3',
    'question' => '57X4=',
    'answer' => '228',
  ),
);
?>