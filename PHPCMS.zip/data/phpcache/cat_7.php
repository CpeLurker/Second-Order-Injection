<?php
$data = array (
  'catid' => '7',
  'catname' => '兼职实习',
  'keywords' => '家教 会计 模特 礼仪 设计 网站 摄影 演员 翻译 客服 其他兼职 实习生 销售 派发 促销 临时工/小时工 充场/座谈会',
  'description' => '天水信息网兼职实习栏目包括：家教 会计 模特 礼仪 设计 网站 摄影 演员 翻译 客服 其他兼职 实习生 销售 派发 促销 临时工/小时工 充场/座谈会',
  'parentid' => '0',
  'catorder' => '7',
  'cattplname' => '0',
  'viewtplname' => '0',
);
?>