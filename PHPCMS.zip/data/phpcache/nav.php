<?php
$data = array (
  0 => 
  array (
    'id' => '1',
    'navname' => '首页',
    'url' => 'index.php',
    'target' => '_self',
    'navorder' => '1',
  ),
  1 => 
  array (
    'id' => '4',
    'navname' => '教育培训',
    'url' => 'category.php?id=9',
    'target' => '_blank',
    'navorder' => '2',
  ),
  2 => 
  array (
    'id' => '5',
    'navname' => '个人求职',
    'url' => 'category.php?id=10',
    'target' => '_blank',
    'navorder' => '3',
  ),
  3 => 
  array (
    'id' => '6',
    'navname' => '企业招聘',
    'url' => 'category.php?id=4',
    'target' => '_blank',
    'navorder' => '4',
  ),
  4 => 
  array (
    'id' => '7',
    'navname' => '房屋租售',
    'url' => 'category.php?id=3',
    'target' => '_blank',
    'navorder' => '5',
  ),
  5 => 
  array (
    'id' => '8',
    'navname' => '交友活动',
    'url' => 'category.php?id=6',
    'target' => '_blank',
    'navorder' => '6',
  ),
  6 => 
  array (
    'id' => '9',
    'navname' => '物品交易',
    'url' => 'category.php?id=1',
    'target' => '_blank',
    'navorder' => '7',
  ),
);
?>