<?php
$data = array (
  0 => 
  array (
    'areaid' => '1',
    'areaname' => '秦州区',
  ),
  1 => 
  array (
    'areaid' => '2',
    'areaname' => '麦积区',
  ),
  2 => 
  array (
    'areaid' => '3',
    'areaname' => '武山县',
  ),
  3 => 
  array (
    'areaid' => '4',
    'areaname' => '甘谷县',
  ),
  4 => 
  array (
    'areaid' => '5',
    'areaname' => '秦安县',
  ),
  5 => 
  array (
    'areaid' => '6',
    'areaname' => '张家川',
  ),
  6 => 
  array (
    'areaid' => '7',
    'areaname' => '甘谷县',
  ),
);
?>