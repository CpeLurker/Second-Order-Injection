<?php
$data = NULL;
?>