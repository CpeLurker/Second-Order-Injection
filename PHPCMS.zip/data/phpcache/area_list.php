<?php
$data = array (
  1 => 
  array (
    'areaid' => '1',
    'areaname' => '秦州区',
    'url' => 'category.php?area=1',
  ),
  2 => 
  array (
    'areaid' => '2',
    'areaname' => '麦积区',
    'url' => 'category.php?area=2',
  ),
  3 => 
  array (
    'areaid' => '3',
    'areaname' => '武山县',
    'url' => 'category.php?area=3',
  ),
  4 => 
  array (
    'areaid' => '4',
    'areaname' => '甘谷县',
    'url' => 'category.php?area=4',
  ),
  5 => 
  array (
    'areaid' => '5',
    'areaname' => '秦安县',
    'url' => 'category.php?area=5',
  ),
  6 => 
  array (
    'areaid' => '6',
    'areaname' => '张家川',
    'url' => 'category.php?area=6',
  ),
  7 => 
  array (
    'areaid' => '7',
    'areaname' => '甘谷县',
    'url' => 'category.php?area=7',
  ),
);
?>