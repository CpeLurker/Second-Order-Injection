<?php
$data = array (
  'txt' => 
  array (
    0 => 
    array (
      'id' => '1',
      'webname' => '天水网',
      'url' => 'http://www.itianshui.com',
      'linkorder' => '1',
      'logo' => '',
    ),
    1 => 
    array (
      'id' => '2',
      'webname' => '天水新闻',
      'url' => 'http://www.itianshui.com/plus/list.php?tid=3',
      'linkorder' => '2',
      'logo' => '',
    ),
    2 => 
    array (
      'id' => '3',
      'webname' => '甘谷新闻网',
      'url' => 'http://www.itianshui.com/plus/list.php?tid=16',
      'linkorder' => '3',
      'logo' => '',
    ),
    3 => 
    array (
      'id' => '4',
      'webname' => '秦州新闻网',
      'url' => 'http://www.itianshui.com/plus/list.php?tid=17',
      'linkorder' => '4',
      'logo' => '',
    ),
    4 => 
    array (
      'id' => '5',
      'webname' => '麦积新闻网',
      'url' => 'http://www.itianshui.com/plus/list.php?tid=18',
      'linkorder' => '5',
      'logo' => '',
    ),
    5 => 
    array (
      'id' => '6',
      'webname' => '秦安新闻网',
      'url' => 'http://www.itianshui.com/plus/list.php?tid=19',
      'linkorder' => '6',
      'logo' => '',
    ),
    6 => 
    array (
      'id' => '7',
      'webname' => '张川新闻网',
      'url' => 'http://www.itianshui.com/plus/list.php?tid=20',
      'linkorder' => '7',
      'logo' => '',
    ),
    7 => 
    array (
      'id' => '8',
      'webname' => '武山新闻网',
      'url' => 'http://www.itianshui.com/plus/list.php?tid=21',
      'linkorder' => '8',
      'logo' => '',
    ),
    8 => 
    array (
      'id' => '9',
      'webname' => '清水新闻网',
      'url' => 'http://www.itianshui.com/plus/list.php?tid=22',
      'linkorder' => '9',
      'logo' => '',
    ),
  ),
);
?>