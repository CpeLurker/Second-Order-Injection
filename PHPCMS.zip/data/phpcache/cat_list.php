<?php
$data = array (
  1 => 
  array (
    'catid' => '1',
    'catname' => '物品交易',
    'caturl' => 'category.php?id=1',
    'children' => 
    array (
      11 => 
      array (
        'id' => '11',
        'name' => '二手台式电脑',
        'url' => 'category.php?id=11',
      ),
      12 => 
      array (
        'id' => '12',
        'name' => '电脑配件/宽带',
        'url' => 'category.php?id=12',
      ),
      13 => 
      array (
        'id' => '13',
        'name' => '笔记本/IPAD',
        'url' => 'category.php?id=13',
      ),
      14 => 
      array (
        'id' => '14',
        'name' => '手机交易',
        'url' => 'category.php?id=14',
      ),
      15 => 
      array (
        'id' => '15',
        'name' => '手机号码交易',
        'url' => 'category.php?id=15',
      ),
      16 => 
      array (
        'id' => '16',
        'name' => '照相机/摄像机',
        'url' => 'category.php?id=16',
      ),
      17 => 
      array (
        'id' => '17',
        'name' => 'MP3游戏机',
        'url' => 'category.php?id=17',
      ),
      18 => 
      array (
        'id' => '18',
        'name' => '日用品',
        'url' => 'category.php?id=18',
      ),
      19 => 
      array (
        'id' => '19',
        'name' => '食品',
        'url' => 'category.php?id=19',
      ),
      20 => 
      array (
        'id' => '20',
        'name' => '二手家用电器',
        'url' => 'category.php?id=20',
      ),
      21 => 
      array (
        'id' => '21',
        'name' => '二手家具',
        'url' => 'category.php?id=21',
      ),
      22 => 
      array (
        'id' => '22',
        'name' => '办公耗材/家具',
        'url' => 'category.php?id=22',
      ),
      23 => 
      array (
        'id' => '23',
        'name' => '收藏品/工艺品',
        'url' => 'category.php?id=23',
      ),
      24 => 
      array (
        'id' => '24',
        'name' => '女装/男装',
        'url' => 'category.php?id=24',
      ),
      25 => 
      array (
        'id' => '25',
        'name' => '配饰/钟表',
        'url' => 'category.php?id=25',
      ),
      26 => 
      array (
        'id' => '26',
        'name' => '箱包/鞋帽',
        'url' => 'category.php?id=26',
      ),
      27 => 
      array (
        'id' => '27',
        'name' => '化妆品',
        'url' => 'category.php?id=27',
      ),
      28 => 
      array (
        'id' => '28',
        'name' => '母婴/幼儿玩具',
        'url' => 'category.php?id=28',
      ),
      29 => 
      array (
        'id' => '29',
        'name' => '书报/音响',
        'url' => 'category.php?id=29',
      ),
      30 => 
      array (
        'id' => '30',
        'name' => '二手乐器/文具',
        'url' => 'category.php?id=30',
      ),
      31 => 
      array (
        'id' => '31',
        'name' => '二手运动器材',
        'url' => 'category.php?id=31',
      ),
      32 => 
      array (
        'id' => '32',
        'name' => '消费卡/优惠劵',
        'url' => 'category.php?id=32',
      ),
      33 => 
      array (
        'id' => '33',
        'name' => '门票/电影票',
        'url' => 'category.php?id=33',
      ),
      34 => 
      array (
        'id' => '34',
        'name' => '火车票/汽车票',
        'url' => 'category.php?id=34',
      ),
      35 => 
      array (
        'id' => '35',
        'name' => '工业设备',
        'url' => 'category.php?id=35',
      ),
      36 => 
      array (
        'id' => '36',
        'name' => '其他转让物品',
        'url' => 'category.php?id=36',
      ),
      37 => 
      array (
        'id' => '37',
        'name' => '物品交换',
        'url' => 'category.php?id=37',
      ),
      38 => 
      array (
        'id' => '38',
        'name' => '物品求购',
        'url' => 'category.php?id=38',
      ),
    ),
  ),
  2 => 
  array (
    'catid' => '2',
    'catname' => '车辆买卖',
    'caturl' => 'category.php?id=2',
    'children' => 
    array (
      39 => 
      array (
        'id' => '39',
        'name' => '二手车',
        'url' => 'category.php?id=39',
      ),
      40 => 
      array (
        'id' => '40',
        'name' => '汽车用品/配件',
        'url' => 'category.php?id=40',
      ),
      41 => 
      array (
        'id' => '41',
        'name' => '摩托车/燃气车',
        'url' => 'category.php?id=41',
      ),
      42 => 
      array (
        'id' => '42',
        'name' => '电动车',
        'url' => 'category.php?id=42',
      ),
      43 => 
      array (
        'id' => '43',
        'name' => '自行车',
        'url' => 'category.php?id=43',
      ),
      44 => 
      array (
        'id' => '44',
        'name' => '车辆求购',
        'url' => 'category.php?id=44',
      ),
      45 => 
      array (
        'id' => '45',
        'name' => '租车',
        'url' => 'category.php?id=45',
      ),
      46 => 
      array (
        'id' => '46',
        'name' => '新车',
        'url' => 'category.php?id=46',
      ),
      47 => 
      array (
        'id' => '47',
        'name' => '4S店/经销商',
        'url' => 'category.php?id=47',
      ),
    ),
  ),
  3 => 
  array (
    'catid' => '3',
    'catname' => '房屋租售',
    'caturl' => 'category.php?id=3',
    'children' => 
    array (
      48 => 
      array (
        'id' => '48',
        'name' => '房屋出租',
        'url' => 'category.php?id=48',
      ),
      49 => 
      array (
        'id' => '49',
        'name' => '房屋求租',
        'url' => 'category.php?id=49',
      ),
      50 => 
      array (
        'id' => '50',
        'name' => '房屋合租',
        'url' => 'category.php?id=50',
      ),
      51 => 
      array (
        'id' => '51',
        'name' => '二手房买卖',
        'url' => 'category.php?id=51',
      ),
      52 => 
      array (
        'id' => '52',
        'name' => '新房出售',
        'url' => 'category.php?id=52',
      ),
      53 => 
      array (
        'id' => '53',
        'name' => '短租房/日租房',
        'url' => 'category.php?id=53',
      ),
      54 => 
      array (
        'id' => '54',
        'name' => '写字楼租售',
        'url' => 'category.php?id=54',
      ),
      55 => 
      array (
        'id' => '55',
        'name' => '生意/商场/办公房',
        'url' => 'category.php?id=55',
      ),
      56 => 
      array (
        'id' => '56',
        'name' => '商务房',
        'url' => 'category.php?id=56',
      ),
      57 => 
      array (
        'id' => '57',
        'name' => '厂房/仓库/土地',
        'url' => 'category.php?id=57',
      ),
    ),
  ),
  4 => 
  array (
    'catid' => '4',
    'catname' => '招聘工作',
    'caturl' => 'category.php?id=4',
    'children' => 
    array (
      58 => 
      array (
        'id' => '58',
        'name' => '营业员',
        'url' => 'category.php?id=58',
      ),
      59 => 
      array (
        'id' => '59',
        'name' => '店长',
        'url' => 'category.php?id=59',
      ),
      60 => 
      array (
        'id' => '60',
        'name' => '服务员',
        'url' => 'category.php?id=60',
      ),
      61 => 
      array (
        'id' => '61',
        'name' => '收银员',
        'url' => 'category.php?id=61',
      ),
      62 => 
      array (
        'id' => '62',
        'name' => '销售/业务员',
        'url' => 'category.php?id=62',
      ),
      63 => 
      array (
        'id' => '63',
        'name' => '房产类工作',
        'url' => 'category.php?id=63',
      ),
      64 => 
      array (
        'id' => '64',
        'name' => '金融保险',
        'url' => 'category.php?id=64',
      ),
      65 => 
      array (
        'id' => '65',
        'name' => '文员/办公',
        'url' => 'category.php?id=65',
      ),
      66 => 
      array (
        'id' => '66',
        'name' => '商务助理',
        'url' => 'category.php?id=66',
      ),
      67 => 
      array (
        'id' => '67',
        'name' => '前台',
        'url' => 'category.php?id=67',
      ),
      68 => 
      array (
        'id' => '68',
        'name' => '行政工作',
        'url' => 'category.php?id=68',
      ),
      69 => 
      array (
        'id' => '69',
        'name' => '人事',
        'url' => 'category.php?id=69',
      ),
      70 => 
      array (
        'id' => '70',
        'name' => '客服',
        'url' => 'category.php?id=70',
      ),
      71 => 
      array (
        'id' => '71',
        'name' => '市场运营',
        'url' => 'category.php?id=71',
      ),
      72 => 
      array (
        'id' => '72',
        'name' => '家政保洁',
        'url' => 'category.php?id=72',
      ),
      73 => 
      array (
        'id' => '73',
        'name' => '司机工作',
        'url' => 'category.php?id=73',
      ),
      74 => 
      array (
        'id' => '74',
        'name' => '保安',
        'url' => 'category.php?id=74',
      ),
      75 => 
      array (
        'id' => '75',
        'name' => '厨师',
        'url' => 'category.php?id=75',
      ),
      76 => 
      array (
        'id' => '76',
        'name' => '切配',
        'url' => 'category.php?id=76',
      ),
      77 => 
      array (
        'id' => '77',
        'name' => '送货员工作',
        'url' => 'category.php?id=77',
      ),
      78 => 
      array (
        'id' => '78',
        'name' => '快递员工作',
        'url' => 'category.php?id=78',
      ),
      79 => 
      array (
        'id' => '79',
        'name' => '仓管',
        'url' => 'category.php?id=79',
      ),
      80 => 
      array (
        'id' => '80',
        'name' => '网管工作',
        'url' => 'category.php?id=80',
      ),
      81 => 
      array (
        'id' => '81',
        'name' => '招聘工人技工',
        'url' => 'category.php?id=81',
      ),
      82 => 
      array (
        'id' => '82',
        'name' => '招聘财务/会计出纳',
        'url' => 'category.php?id=82',
      ),
      83 => 
      array (
        'id' => '83',
        'name' => '招聘IT/互联网',
        'url' => 'category.php?id=83',
      ),
      84 => 
      array (
        'id' => '84',
        'name' => '[招聘]教育培训/咨询',
        'url' => 'category.php?id=84',
      ),
      85 => 
      array (
        'id' => '85',
        'name' => '[招聘]广告/媒体/设计',
        'url' => 'category.php?id=85',
      ),
      86 => 
      array (
        'id' => '86',
        'name' => '招聘建筑/装潢/园林',
        'url' => 'category.php?id=86',
      ),
      87 => 
      array (
        'id' => '87',
        'name' => '招聘编辑',
        'url' => 'category.php?id=87',
      ),
      88 => 
      array (
        'id' => '88',
        'name' => '招聘摄影',
        'url' => 'category.php?id=88',
      ),
      89 => 
      array (
        'id' => '89',
        'name' => '招聘翻译',
        'url' => 'category.php?id=89',
      ),
      90 => 
      array (
        'id' => '90',
        'name' => '招聘美容美发',
        'url' => 'category.php?id=90',
      ),
      91 => 
      array (
        'id' => '91',
        'name' => '保健按摩',
        'url' => 'category.php?id=91',
      ),
      92 => 
      array (
        'id' => '92',
        'name' => '招聘会',
        'url' => 'category.php?id=92',
      ),
      93 => 
      array (
        'id' => '93',
        'name' => '招聘KTV/酒吧',
        'url' => 'category.php?id=93',
      ),
      94 => 
      array (
        'id' => '94',
        'name' => '其他招聘工作',
        'url' => 'category.php?id=94',
      ),
    ),
  ),
  5 => 
  array (
    'catid' => '5',
    'catname' => '生活服务',
    'caturl' => 'category.php?id=5',
    'children' => 
    array (
      95 => 
      array (
        'id' => '95',
        'name' => '租车',
        'url' => 'category.php?id=95',
      ),
      96 => 
      array (
        'id' => '96',
        'name' => '驾校',
        'url' => 'category.php?id=96',
      ),
      97 => 
      array (
        'id' => '97',
        'name' => '陪驾/代驾服务',
        'url' => 'category.php?id=97',
      ),
      98 => 
      array (
        'id' => '98',
        'name' => '汽车检修/保养',
        'url' => 'category.php?id=98',
      ),
      99 => 
      array (
        'id' => '99',
        'name' => '家政保姆服务',
        'url' => 'category.php?id=99',
      ),
      100 => 
      array (
        'id' => '100',
        'name' => '保洁清洗服务',
        'url' => 'category.php?id=100',
      ),
      101 => 
      array (
        'id' => '101',
        'name' => '装修服务',
        'url' => 'category.php?id=101',
      ),
      102 => 
      array (
        'id' => '102',
        'name' => '下水管疏通',
        'url' => 'category.php?id=102',
      ),
      103 => 
      array (
        'id' => '103',
        'name' => '建筑装饰',
        'url' => 'category.php?id=103',
      ),
      104 => 
      array (
        'id' => '104',
        'name' => '家居装修',
        'url' => 'category.php?id=104',
      ),
      105 => 
      array (
        'id' => '105',
        'name' => '搬家服务',
        'url' => 'category.php?id=105',
      ),
      106 => 
      array (
        'id' => '106',
        'name' => '快递物流',
        'url' => 'category.php?id=106',
      ),
      107 => 
      array (
        'id' => '107',
        'name' => '电脑维修',
        'url' => 'category.php?id=107',
      ),
      108 => 
      array (
        'id' => '108',
        'name' => '家电维修',
        'url' => 'category.php?id=108',
      ),
      109 => 
      array (
        'id' => '109',
        'name' => '招商/加盟/代理',
        'url' => 'category.php?id=109',
      ),
      110 => 
      array (
        'id' => '110',
        'name' => '公司注册/年检',
        'url' => 'category.php?id=110',
      ),
      111 => 
      array (
        'id' => '111',
        'name' => '担保贷款',
        'url' => 'category.php?id=111',
      ),
      112 => 
      array (
        'id' => '112',
        'name' => '投资理财/保险',
        'url' => 'category.php?id=112',
      ),
      113 => 
      array (
        'id' => '113',
        'name' => '会计/审计/评估',
        'url' => 'category.php?id=113',
      ),
      114 => 
      array (
        'id' => '114',
        'name' => '旅游',
        'url' => 'category.php?id=114',
      ),
      115 => 
      array (
        'id' => '115',
        'name' => '酒店',
        'url' => 'category.php?id=115',
      ),
      116 => 
      array (
        'id' => '116',
        'name' => '机票/签证',
        'url' => 'category.php?id=116',
      ),
      117 => 
      array (
        'id' => '117',
        'name' => '网站建设/推广',
        'url' => 'category.php?id=117',
      ),
      118 => 
      array (
        'id' => '118',
        'name' => '鲜花礼仪',
        'url' => 'category.php?id=118',
      ),
      119 => 
      array (
        'id' => '119',
        'name' => '礼品/定制',
        'url' => 'category.php?id=119',
      ),
      120 => 
      array (
        'id' => '120',
        'name' => '美容美体',
        'url' => 'category.php?id=120',
      ),
      121 => 
      array (
        'id' => '121',
        'name' => '婚庆/化妆/司仪',
        'url' => 'category.php?id=121',
      ),
      122 => 
      array (
        'id' => '122',
        'name' => '摄影服务',
        'url' => 'category.php?id=122',
      ),
      123 => 
      array (
        'id' => '123',
        'name' => '设计策划',
        'url' => 'category.php?id=123',
      ),
      124 => 
      array (
        'id' => '124',
        'name' => '广告印刷',
        'url' => 'category.php?id=124',
      ),
      125 => 
      array (
        'id' => '125',
        'name' => '翻译',
        'url' => 'category.php?id=125',
      ),
      126 => 
      array (
        'id' => '126',
        'name' => '律师',
        'url' => 'category.php?id=126',
      ),
      127 => 
      array (
        'id' => '127',
        'name' => '物品/设备租赁',
        'url' => 'category.php?id=127',
      ),
      128 => 
      array (
        'id' => '128',
        'name' => '物品回收',
        'url' => 'category.php?id=128',
      ),
      129 => 
      array (
        'id' => '129',
        'name' => '其他服务',
        'url' => 'category.php?id=129',
      ),
    ),
  ),
  6 => 
  array (
    'catid' => '6',
    'catname' => '征婚交友/同城活动',
    'caturl' => 'category.php?id=6',
    'children' => 
    array (
      130 => 
      array (
        'id' => '130',
        'name' => '男士征婚',
        'url' => 'category.php?id=130',
      ),
      131 => 
      array (
        'id' => '131',
        'name' => '女士征婚',
        'url' => 'category.php?id=131',
      ),
      132 => 
      array (
        'id' => '132',
        'name' => '找男朋友',
        'url' => 'category.php?id=132',
      ),
      133 => 
      array (
        'id' => '133',
        'name' => '找女朋友',
        'url' => 'category.php?id=133',
      ),
      134 => 
      array (
        'id' => '134',
        'name' => '拼车/顺风车',
        'url' => 'category.php?id=134',
      ),
      135 => 
      array (
        'id' => '135',
        'name' => '同城聚会',
        'url' => 'category.php?id=135',
      ),
      136 => 
      array (
        'id' => '136',
        'name' => '运动打球',
        'url' => 'category.php?id=136',
      ),
      137 => 
      array (
        'id' => '137',
        'name' => '结伴出游',
        'url' => 'category.php?id=137',
      ),
      138 => 
      array (
        'id' => '138',
        'name' => '技能交换',
        'url' => 'category.php?id=138',
      ),
      139 => 
      array (
        'id' => '139',
        'name' => '寻人/寻物',
        'url' => 'category.php?id=139',
      ),
      140 => 
      array (
        'id' => '140',
        'name' => '老乡会',
        'url' => 'category.php?id=140',
      ),
      141 => 
      array (
        'id' => '141',
        'name' => '同学会',
        'url' => 'category.php?id=141',
      ),
      142 => 
      array (
        'id' => '142',
        'name' => '兴趣交友',
        'url' => 'category.php?id=142',
      ),
      143 => 
      array (
        'id' => '143',
        'name' => '真情告白/祝福',
        'url' => 'category.php?id=143',
      ),
    ),
  ),
  7 => 
  array (
    'catid' => '7',
    'catname' => '兼职实习',
    'caturl' => 'category.php?id=7',
    'children' => 
    array (
      144 => 
      array (
        'id' => '144',
        'name' => '家教',
        'url' => 'category.php?id=144',
      ),
      145 => 
      array (
        'id' => '145',
        'name' => '会计',
        'url' => 'category.php?id=145',
      ),
      146 => 
      array (
        'id' => '146',
        'name' => '模特',
        'url' => 'category.php?id=146',
      ),
      147 => 
      array (
        'id' => '147',
        'name' => '礼仪',
        'url' => 'category.php?id=147',
      ),
      148 => 
      array (
        'id' => '148',
        'name' => '设计',
        'url' => 'category.php?id=148',
      ),
      149 => 
      array (
        'id' => '149',
        'name' => '网站',
        'url' => 'category.php?id=149',
      ),
      150 => 
      array (
        'id' => '150',
        'name' => '摄影',
        'url' => 'category.php?id=150',
      ),
      151 => 
      array (
        'id' => '151',
        'name' => '演员',
        'url' => 'category.php?id=151',
      ),
      152 => 
      array (
        'id' => '152',
        'name' => '翻译',
        'url' => 'category.php?id=152',
      ),
      153 => 
      array (
        'id' => '153',
        'name' => '客服',
        'url' => 'category.php?id=153',
      ),
      154 => 
      array (
        'id' => '154',
        'name' => '其他兼职',
        'url' => 'category.php?id=154',
      ),
      155 => 
      array (
        'id' => '155',
        'name' => '实习生',
        'url' => 'category.php?id=155',
      ),
      156 => 
      array (
        'id' => '156',
        'name' => '销售',
        'url' => 'category.php?id=156',
      ),
      157 => 
      array (
        'id' => '157',
        'name' => '派发',
        'url' => 'category.php?id=157',
      ),
      158 => 
      array (
        'id' => '158',
        'name' => '促销',
        'url' => 'category.php?id=158',
      ),
      159 => 
      array (
        'id' => '159',
        'name' => '临时工/小时工',
        'url' => 'category.php?id=159',
      ),
      160 => 
      array (
        'id' => '160',
        'name' => '充场/座谈会',
        'url' => 'category.php?id=160',
      ),
    ),
  ),
  8 => 
  array (
    'catid' => '8',
    'catname' => '宠物',
    'caturl' => 'category.php?id=8',
    'children' => 
    array (
      161 => 
      array (
        'id' => '161',
        'name' => '宠物狗',
        'url' => 'category.php?id=161',
      ),
      162 => 
      array (
        'id' => '162',
        'name' => '猫/其他宠物',
        'url' => 'category.php?id=162',
      ),
      163 => 
      array (
        'id' => '163',
        'name' => '宠物免费收养',
        'url' => 'category.php?id=163',
      ),
      164 => 
      array (
        'id' => '164',
        'name' => '宠物用品/食品',
        'url' => 'category.php?id=164',
      ),
      165 => 
      array (
        'id' => '165',
        'name' => '宠物医院',
        'url' => 'category.php?id=165',
      ),
      166 => 
      array (
        'id' => '166',
        'name' => '犬舍/宠物店',
        'url' => 'category.php?id=166',
      ),
    ),
  ),
  9 => 
  array (
    'catid' => '9',
    'catname' => '教育培训',
    'caturl' => 'category.php?id=9',
    'children' => 
    array (
      167 => 
      array (
        'id' => '167',
        'name' => '电脑培训',
        'url' => 'category.php?id=167',
      ),
      168 => 
      array (
        'id' => '168',
        'name' => '外语培训',
        'url' => 'category.php?id=168',
      ),
      169 => 
      array (
        'id' => '169',
        'name' => '学历培训',
        'url' => 'category.php?id=169',
      ),
      170 => 
      array (
        'id' => '170',
        'name' => '婴幼儿教育',
        'url' => 'category.php?id=170',
      ),
      171 => 
      array (
        'id' => '171',
        'name' => '设计培训',
        'url' => 'category.php?id=171',
      ),
      172 => 
      array (
        'id' => '172',
        'name' => '职业技能培训',
        'url' => 'category.php?id=172',
      ),
      173 => 
      array (
        'id' => '173',
        'name' => '艺术/体育/培训',
        'url' => 'category.php?id=173',
      ),
      174 => 
      array (
        'id' => '174',
        'name' => '中小学教育',
        'url' => 'category.php?id=174',
      ),
    ),
  ),
  10 => 
  array (
    'catid' => '10',
    'catname' => '求职简历',
    'caturl' => 'category.php?id=10',
    'children' => 
    array (
      175 => 
      array (
        'id' => '175',
        'name' => '全职求职简历',
        'url' => 'category.php?id=175',
      ),
      176 => 
      array (
        'id' => '176',
        'name' => '简直求职简历',
        'url' => 'category.php?id=176',
      ),
    ),
  ),
);
?>