<?php if(!defined('IN_PHPMPS'))die('Access Denied'); ?>	<!-- 页脚 -->
<DIV class=nohist id=footer>
  <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
    <TBODY>
      <TR>
        <TD style="TEXT-ALIGN: left"><a onclick="this.style.behavior='url(#default#homepage)';this.setHomePage('<?=$CFG[weburl]?>');return(false);" style="cursor:pointer;">设为首页</a> | <a href=javascript:window.external.AddFavorite('<?php echo $CFG['weburl'];?>','<?php echo $CFG['webname'];?>')>加为收藏</a> | <a href=help.php>帮助中心</a> | 网站统计
          
<?php if(is_array($about)) foreach($about AS $key => $val) { ?>
          <a href=<?php echo $val['url'];?> target=_blank><?php echo $val['title'];?></a> <?php if($key<(count($about)-1)) { ?> | <?php } ?>
          
<?php } ?>

          <BR>&copy;CopyRight <a href="http://info.itianshui.com">天水信息网</a>2008-2012 All Rights Reserved.
          <DIV style="FLOAT: right">
  	 <?php if($CFG['count']) { ?>	<?php echo $CFG['count'];?>	<?php } ?>
        </DIV>
          <BR>
      </TR>
    </TBODY>
  </TABLE>
</DIV>
 
<!-- 页脚 结束 -->
