<?php if(!defined('IN_PHPMPS'))die('Access Denied'); ?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml">
<HEAD>
<title><?php echo $seo['title'];?></title>
<meta name="Keywords" content="<?php echo $seo['keywords'];?>">
<meta name="Description" content="<?php echo $seo['description'];?>">
<link href="templates/<?php echo $CFG['tplname'];?>/images/tcw.css" type="text/css" rel="stylesheet" />
<META content="MSHTML 6.00.6000.17063" name=GENERATOR>
</HEAD>
<BODY>

<?php include template(header); ?>

<!--navi-->
<DIV id=container>
<DIV id=subheader>
  <h1><?php echo $seo['title'];?></h1> 
<div class="blank"></div> 
  <DIV class=enhist id=filter>
    <DIV class=b>
      <FORM action=search.php method=get target=_self>
        <A id=filter 
style="DISPLAY: none"></A>
<table cellpadding="0" cellspacing="0" border="0" width="100%" id="filterTable">
    <?php if($cat_arr || $area_arr) { ?>
<?php if($area_arr) { ?>
    <tr class="old" id="areaFilter">
<td width="75px" align="right" valign="top">地域查找：</td>
<td>
<?php if(is_array($area_arr)) foreach($area_arr AS $val) { ?>
<a href=<?php echo $val['url'];?>> <?php echo $val['areaname'];?></a>&nbsp;

<?php } ?>

</td>
</tr>
<?php } ?>
<?php if($cat_arr) { ?>
 <tr class="old" id="areaFilter"><td width="75px" align="right" valign="top">分类查找：</td>
<td>
<?php if(is_array($cat_arr)) foreach($cat_arr AS $val) { ?>
<a href=<?php echo $val['url'];?>> <?php echo $val['catname'];?></a>&nbsp;

<?php } ?>

</td>
</tr>
<?php } ?>
<?php } ?>
          <tr class=old>
              <TD align=right>搜索：</TD>
              <TD class=search><INPUT class=input id=keywords alt="搜索: 请输入关键字" size=30 value=招聘 name=keywords>
                <INPUT type=hidden value=keywords>
                <INPUT class=submit type=submit value=搜索>
                关键字：<A href="/search.php?keywords=电动车" target=_blank>电动车</A> <A href="/search.php?keywords=搬家" target=_blank>搬家</A> <A href="/search.php?keywords=快递"  target=_blank>快递</A> <A href="/search.php?keywords=大学生"target=_blank>大学生</A> <A href="/search.php?keywords=诺基亚手机" target=_blank>诺基亚手机</A> <A href="/search.php?keywords=广告设计" target=_blank>广告设计</A> ...</TD>
            </TR>
          </TBODY>
        </TABLE>
      </FORM>
    </DIV>
  </DIV>
  <!-- filter -->
</DIV>
<!-- subheader -->
<DIV id=content style="HEIGHT: 1000px">
<SCRIPT src="images/ads.js" type=text/javascript></SCRIPT>
<DIV style="PADDING-BOTTOM: 10px"> <A href="#" target=_blank rel=nofollow> <IMG style="BORDER-TOP-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px" alt=金牌置顶 src="images/indexad_1.gif" width=948></A> </DIV>
<DIV id=left>
<DIV class="datagrid enhist" id=datagrid>
<OL>
  <LI class=head><A 
  style="PADDING-RIGHT: 5px; FONT-WEIGHT: normal; FONT-SIZE: 12px; FLOAT: right" href="/ad/" target=_blank rel=nofollow>我的信息也想出现在这里</A><A 
  href="/ad/" target=_blank rel=nofollow>【本类置顶信息】</A> 
  <?php if(is_array($top_info)) foreach($top_info AS $article) { ?>
   <LI style="background-color:#f3f3f3; ">【置顶】【20<?php echo $article['postdate'];?>发布】<A href="<?php echo $article['url'];?>"><?php echo $article['title'];?></A><?php if($article[thumb]) { ?><i>&nbsp;图&nbsp;</i><?php } ?><EM class=m>&nbsp;<?php echo $article['catname'];?>&nbsp;/&nbsp;<?php echo $article['areaname'];?>&nbsp;
  <?php if(is_array($article[custom])) foreach($article[custom] AS $cus) { ?> <?php echo $cus['cusname'];?>：<?php echo $cus['cusvalue'];?>&nbsp;
  
<?php } ?>
</EM><!--<p style="font-size:12px; "><?php echo $article['intro'];?></p>--></li>
  
<?php } ?>

</OL>
<DIV class=blank10></DIV>
<OL>
<LI class=head><A style="PADDING-RIGHT: 5px">最新信息发布</A>
<LI class="spar dh_hide" style="MARGIN-TOP: -36px; BORDER-TOP-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-LEFT-STYLE: none; TEXT-ALIGN: right; BORDER-BOTTOM-STYLE: none"><A 
  href="#" rel=nofollow><SMALL>置顶，让信息效果更好！</SMALL></A>
  <DIV class=blank10></DIV>
<LI><!--728*90广告位-->
  <DIV class=blank10></DIV>
  
  <?php if(is_array($new_info)) foreach($new_info AS $val) { ?>
  <DIV style="DISPLAY: block; FLOAT: right"><FONT style="FONT-SIZE: 12px">20<?php echo $val['postdate'];?>发布</FONT></DIV>
 <LI><A href="<?php echo $val['url'];?>"><?php echo $val['title'];?></A><EM class=m><?php echo $val['catname'];?>&nbsp;/&nbsp;<?php echo $val['areaname'];?></EM></li>
  
<?php } ?>

  <!-- 内容列表 -->
 
  
   <?php if(is_array($info)) foreach($info AS $val) { ?>
     <DIV style="DISPLAY: block; FLOAT: right"><FONT style="FONT-SIZE: 12px">20<?php echo $val['postdate'];?>发布</FONT></DIV>
    <LI><?php if($val[thumb]) { ?>【图】&nbsp;<?php } ?><A href="<?php echo $val['url'];?>"><?php echo $val['title'];?></A><EM class=m><?php echo $val['catname'];?>&nbsp;/&nbsp;<?php echo $val['areaname'];?>
  <?php if(is_array($article[custom])) foreach($article[custom] AS $cus) { ?> <?php echo $cus['cusname'];?>：<?php echo $cus['cusvalue'];?>&nbsp;
  
<?php } ?>
</EM><!--<p style="font-size:12px; "><?php echo $val['intro'];?></p>--></li>

<?php } ?>

  
<DIV class=blank10></DIV>
</DIV>
<!--datagrid-->
<DIV class=pager>
<?php include template(page); ?>
<BR>
  <A class=dh_hide style="PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; COLOR: #06c; BORDER-TOP-STYLE: none; PADDING-TOP: 0px; BORDER-RIGHT-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-BOTTOM-STYLE: none" 
href="/post.php" target=_blank rel=nofollow>没有找到想要的信息？马上免费发一条信息。</A></DIV>
<!--pager-->
</DIV>
<!--left-->
<DIV id=right>
  <DIV class=block>
    <DIV class=b>
     广告招商15379868686
    </DIV>
  </DIV>
  <DIV class=blank10></DIV>
  <DIV class=blank10></DIV>
  <DIV class=descr>
  <!-- 广告位: (160 x 600) -->
  </DIV>
  <DIV class=blank10></DIV>
</DIV>
<!--right-->
<DIV style="CLEAR: both"></DIV>
</DIV>
<!--content-->
<SCRIPT>document.getElementById('content').style.height = 'auto';</SCRIPT>
<DIV id=subfooter>
</DIV>
<!-- 主体 结束 -->

<?php include template(footer); ?>

</BODY>
</HTML>

