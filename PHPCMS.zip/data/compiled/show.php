<?php if(!defined('IN_PHPMPS'))die('Access Denied'); ?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset;?>"> 
<meta http-equiv="cache-control" content="no-cache">  
<title>提示信息</title>
<style type="text/css">
<!--
*{margin:0;padding:0;}
body{text-align:center;}
td{font-size: 12px;line-height:150%;}
h1{height:20px;line-height:30px;font-size:12px;text-align:center;background-color:#FF9900;color:#CC0000;}
.box_border{margin:50px auto;border:1px solid #FF9900;width:450px;}
a:link {color: #0000FF;text-decoration: none;}
a:visited {text-decoration: none;color: #003399;}
a:hover {text-decoration: underline;color: #0066FF;}
a:active {text-decoration: none;color: #0066FF;}
.style1 {color: #FFFFFF}
-->
</style>
</head>
<body>
<div class="box_border">
<h1 class="style1">提示信息</h1>
<table width="100%" cellspacing="5" cellpadding="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF">

<br/>
<?php echo $msg;?>
<?php if($url=='goback' || $url=='') { ?>
<br/><a href="javascript:history.back();" >[点击这里返回上一页]</a>
<?php } else { ?>
<br/><a href="<?php echo $url;?>">如果您的浏览器没有自动跳转，请点击这里</a>
<script language="javascript">setTimeout("window.location.replace('<?php echo $url;?>')",'1000');</script>
<?php } ?>

    </td>
  </tr>
</table>
</div>
</body>
</html>