<?php if(!defined('IN_PHPMPS'))die('Access Denied'); ?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml">
<HEAD>
<!-- Use IE7 mode -->
<title><?php echo $seo['title'];?></title>
<meta name="Keywords" content="<?php echo $seo['keywords'];?>">
<meta name="Description" content="<?php echo $seo['description'];?>">
<link rel="shortcut icon" href="favicon.ico" />
<link href="templates/<?php echo $CFG['tplname'];?>/images/tcw.css" type="text/css" rel="stylesheet" />
<META content="MSHTML 6.00.6000.17063" name=GENERATOR>
</HEAD>
<BODY>

<?php include template(header); ?>

<!--navi-->
<DIV id=container>
<DIV id=subheader>
  <DIV class=enhist id=filter>
    <DIV class=b>
      <FORM action=search.php method=get target=_self>
        <A id=filter 
style="DISPLAY: none"></A>
        <TABLE id=filterTable cellSpacing=0 cellPadding=0 width="100%" border=0>
          <TBODY>
            <TR class=old>
              <TD align=right>搜索：</TD>
              <TD class=search><INPUT class=input id=keywords alt="搜索: 请输入关键字" size=30 name=keywords>
                <INPUT type=hidden value=keywords>
                <INPUT class=submit type=submit value=搜索>
                关键字：<A href="/search.php?keywords=电动车" target=_blank>电动车</A> <A href="/search.php?keywords=搬家" target=_blank>搬家</A> <A href="/search.php?keywords=快递"  target=_blank>快递</A> <A href="/search.php?keywords=大学生"target=_blank>大学生</A> <A href="/search.php?keywords=诺基亚手机" target=_blank>诺基亚手机</A> <A href="/search.php?keywords=广告设计" target=_blank>广告设计</A> ...</TD>
            </TR>
          </TBODY>
        </TABLE>
      </FORM>
    </DIV>
  </DIV>
  <!-- filter -->
</DIV>
<!-- subheader --><div id="content" style="height:1000px;">
<DIV style="PADDING-BOTTOM: 1px">
<script type="text/javascript">/*960banner*/ var cpro_id = 'u616932';</script><script src="http://cpro.baidu.com/cpro/ui/c.js" type="text/javascript"></script>
</DIV>

<DIV style="PADDING-BOTTOM: 5px">  <IMG style="BORDER-TOP-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px" alt=金牌置顶 src="images/indexad_1.gif" width=948> </DIV>

<!--广告位-->
<div id="categories"><table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td valign="top">
<div style="border-bottom:1px solid #E1E1E1;  margin-bottom:5px;">
<h3 style="margin:0; background:#F1F1F1; border:1px solid #FFF;" >
<span style="background-position:0px 0;"></span>
<a href="category.php?id=1">物品交易</a>
</h3>
</div>
<div class="s"><a href=category.php?id=11> 二手台式电脑</a></div>
<div class="s"><a href=category.php?id=12> 电脑配件/宽带</a></div>
<div class="s"><a href=category.php?id=13> 笔记本/iPad</a></div>
<div class="s"><a href=category.php?id=14> 二手手机</a></div>
<div class="s"><a href=category.php?id=15> 手机号码交易</a></div>
<div class="s"><a href=category.php?id=16> 照相机/摄像机</a></div>
<div class="s"><a href=category.php?id=17> MP3/游戏机</a></div>
<div class="d"><a href=category.php?id=18> 日用品</a></div>
<div class="d"><a href=category.php?id=19> 食品</a></div>
<div class="s"><a href=category.php?id=20> 二手家用电器</a></div>
<div class="s"><a href=category.php?id=21> 二手家具</a></div>
<div class="s"><a href=category.php?id=22> 办公家具/耗材</a></div>
<div class="s"><a href=category.php?id=23> 收藏品/工艺品</a></div>
<div class="s"><a href=category.php?id=24> 女装/男装</a></div>
<div class="s"><a href=category.php?id=25> 配饰/钟表</a></div>
<div class="s"><a href=category.php?id=26> 鞋帽/箱包</a></div>
<div class="s"><a href=category.php?id=27> 化妆品</a></div>
<div class="s"><a href=category.php?id=28> 母婴/幼儿/玩具</a></div>
<div class="s"><a href=category.php?id=29> 书报/音像</a></div>
<div class="s"><a href=category.php?id=30> 二手乐器/文具</a></div>
<div class="s"><a href=category.php?id=31> 二手运动器材</a></div>
<div class="s"><a href=category.php?id=32> 消费卡/优惠券</a></div>
<div class="s"><a href=category.php?id=33> 门票/电影票</a></div>
<div class="s"><a href=category.php?id=34> 火车票/汽车票</a></div>
<div class="s"><a href=category.php?id=35> 工业设备</a></div>
<div class="s"><a href=category.php?id=36> 其他转让物品</a></div>
<div class="d"><a href=category.php?id=37> 物品交换</a></div>
<div class="d"><a href=category.php?id=38> 求购</a></div>
<div class="blank"></div>
</td><td valign="top">
<div style="border-bottom:1px solid #E1E1E1;  margin-bottom:5px;">
<h3 style="margin:0; background:#F1F1F1; border:1px solid #FFF;" >
<span style="background-position:-10px 0;"></span>
<a href="category.php?id=2">车辆买卖</a>
</h3>
</div>
<div class="s"><a href=category.php?id=39> 二手车</a></div>
<div class="s"><a href=category.php?id=40> 汽车用品/配件</a></div>
<div class="s"><a href=category.php?id=41> 摩托车/燃气车</a></div>
<div class="d"><a href=category.php?id=42> 电动车</a></div>
<div class="d"><a href=category.php?id=43> 自行车</a></div>
<div class="d"><a href=category.php?id=44> 车辆求购</a></div>
<div class="d"><a href=category.php?id=45> 租车</a></div>
<div class="d"><a href=category.php?id=46> 新车</a></div>
<div class="d"><a href=category.php?id=47> 4S店/经销商</a></div>
<div class="s"><a href=category.php?id=category.php?id=177> 陪驾/代驾</a></div>
<div class="blank"></div>
<div style="border-bottom:1px solid #E1E1E1; border-top:1px solid #E1E1E1; margin-bottom:5px;">
<h3 style="margin:0; background:#F1F1F1; border:1px solid #FFF;" >
<span style="background-position:-20px 0;"></span>
<a href="category.php?id=6">交友活动</a>
</h3>
</div>
<div class="s"><a href=category.php?id=130> 男士征婚</a></div>
<div class="s"><a href=category.php?id=131> 女士征婚</a></div>
<div class="s"><a href=category.php?id=132> 找男朋友</a></div>
<div class="s"><a href=category.php?id=133> 找女朋友</a></div>
<div class="s"><a href=category.php?id=134> 拼车顺风车</a></div>
<div class="s"><a href=category.php?id=135> 同城聚会</a></div>
<div class="s"><a href=category.php?id=136> 运动打球</a></div>
<div class="s"><a href=category.php?id=137> 结伴出游</a></div>
<div class="s"><a href=category.php?id=139> 寻人/寻物</a></div>
<div class="s"><a href=category.php?id=140> 同乡会</a></div></div>
<div class="s"><a href=category.php?id=141> 同学会</a></div>
<div class="s"><a href=category.php?id=142> 兴趣交友</a></div>
<div class="s"><a href=category.php?id=143> 真情告白/祝福</a></div>
<div class="blank"></div>
<div style="border-bottom:1px solid #E1E1E1; border-top:1px solid #E1E1E1; margin-bottom:5px;">
<h3 style="margin:0; background:#F1F1F1; border:1px solid #FFF;" >
<span style="background-position:-30px 0;"></span>
<a href="category.php?id=8">宠物</a>
</h3>
</div>
<div class="s"><a href=category.php?id=161> 宠物狗</a></div>
<div class="s"><a href=category.php?id=162> 猫/其他宠物</a></div>
<div class="s"><a href=category.php?id=163> 宠物免费赠送</a></div>
<div class="s"><a href=category.php?id=164> 宠物用品/食品</a></div>
<div class="s"><a href=category.php?id=165> 宠物服务/配种</a></div>
<div class="s"><a href=category.php?id=166> 犬舍/宠物店</a></div>
<div class="blank"></div>
</td><td valign="top">
<div style="border-bottom:1px solid #E1E1E1;  margin-bottom:5px;">
<h3 style="margin:0; background:#F1F1F1; border:1px solid #FFF;" >
<span style="background-position:-20px 0;"></span>
<a href="category.php?id=3">房屋租售</a>
</h3>
</div>
<div class="s"><a href=category.php?id=48> 房屋出租</a></div>
<div class="s"><a href=category.php?id=49> 房屋求租</a></div>
<div class="s"><a href=category.php?id=50> 房屋合租</a></div>
<div class="s"><a href=category.php?id=51> 二手房买卖</a></div>
<div class="s"><a href=category.php?id=52> 新房出售</a></div>
<div class="s"><a href=category.php?id=53> 短租房/日租房</a></div>
<div class="s"><a href=category.php?id=54> 写字楼租售</a></div>
<div class="s"><a href=category.php?id=56> 生意/商铺/办公房</a></div>
<div class="s"><a href=category.php?id=57> 厂房/仓库/土地</a></div>
<div class="blank"></div><div style="border-bottom:1px solid #E1E1E1; border-top:1px solid #E1E1E1; margin-bottom:5px;">
<h3 style="margin:0; background:#F1F1F1; border:1px solid #FFF;" >
<span style="background-position:-30px 0;"></span>
<a href="category.php?id=7">兼职实习</a>
</h3>
</div>
<div class="d"><a href=category.php?id=144> 家教</a></div>
<div class="d"><a href=category.php?id=145> 会计</a></div>
<div class="d"><a href=category.php?id=146> 模特</a></div>
<div class="d"><a href=category.php?id=147> 礼仪</a></div>
<div class="d"><a href=category.php?id=148> 设计</a></div>
<div class="d"><a href=category.php?id=149> 网站</a></div>
<div class="d"><a href=category.php?id=150> 摄影</a></div>
<div class="d"><a href=category.php?id=151> 演员</a></div>
<div class="d"><a href=category.php?id=152> 翻译</a></div>
<div class="d"><a href=category.php?id=153> 客服</a></div>
<div class="s"><a href=category.php?id=154> 其他兼职</a></div>
<div class="d"><a href=category.php?id=155> 实习生</a></div>
<div class="d"><a href=category.php?id=156> 销售</a></div>
<div class="d"><a href=category.php?id=157> 派发</a></div>
<div class="d"><a href=category.php?id=158> 促销</a></div>
<div class="s"><a href=category.php?id=159> 临时工/小时工</a></div>
<div class="s"><a href=category.php?id=160> 充场/座谈会</a></div>
<div class="blank"></div><div style="border-bottom:1px solid #E1E1E1; border-top:1px solid #E1E1E1; margin-bottom:5px;">
<h3 style="margin:0; background:#F1F1F1; border:1px solid #FFF;" >
<span style="background-position:-40px 0;"></span>
<a href="category.php?id=9">教育培训</a>
</h3>
</div>
<div class="s"><a href=category.php?id=167> 电脑培训</a></div>
<div class="s"><a href=category.php?id=168> 外语培训</a></div>
<div class="s"><a href=category.php?id=169> 学历教育</a></div>
<div class="s"><a href=category.php?id=170> 婴幼儿教育</a></div>
<div class="s"><a href=category.php?id=171> 设计培训</a></div>
<div class="s"><a href=category.php?id=172> 职业技能培训</a></div>
<div class="s"><a href=category.php?id=173> 文艺/体育培训</a></div>
<div class="s"><a href=category.php?id=174> 中小学教育</a></div>
<div class="blank"></div>
</td><td valign="top">
<div style="border-bottom:1px solid #E1E1E1;  margin-bottom:5px;">
<h3 style="margin:0; background:#F1F1F1; border:1px solid #FFF;" >
<span style="background-position:-30px 0;"></span>
<a href="category.php?id=4">工作招聘</a>
</h3>
</div>
<div class="d"><a href=category.php?id=58> 营业员</a></div>
 
<div class="d"><a href=category.php?id=59> 店长</a></div>
 
<div class="d"><a href=category.php?id=60> 服务员</a></div>
 
<div class="d"><a href=category.php?id=61> 收银员</a></div>
 
<div class="d"><a href=category.php?id=62> 销售/业务员</a></div>
 
<div class="d"><a href=category.php?id=63> 房地产</a></div>
 
<div class="d"><a href=category.php?id=64> 保险</a></div>
 
<div class="d"><a href=category.php?id=65> 文员</a></div>
 
<div class="d"><a href=category.php?id=66> 助理</a></div>
 
<div class="d"><a href=category.php?id=67> 前台</a></div>
 
<div class="d"><a href=category.php?id=68> 行政</a></div>
 
<div class="d"><a href=category.php?id=69> 人事</a></div>
 
<div class="d"><a href=category.php?id=70> 客服</a></div>
 
<div class="s"><a href=category.php?id=71> 市场/运营</a></div>
 
<div class="s"><a href=category.php?id=72> 家政/保洁</a></div>
 
<div class="d"><a href=category.php?id=73> 司机</a></div>
 
<div class="d"><a href=category.php?id=74> 保安</a></div>
 
<div class="d"><a href=category.php?id=75> 厨师</a></div>
 
<div class="d"><a href=category.php?id=76> 切配</a></div>
 
<div class="d"><a href=category.php?id=77> 送货员</a></div>
 
<div class="d"><a href=category.php?id=78> 快递员</a></div>
 
<div class="d"><a href=category.php?id=79> 仓管</a></div>
 
<div class="d"><a href=category.php?id=80> 网管</a></div>
 
<div class="s"><a href=category.php?id=81> 工人/技工</a></div>
 
<div class="s"><a href=category.php?id=82> 财务/会计/出纳</a></div>
 
<div class="s"><a href=category.php?id=83> IT/互联网</a></div>
 
<div class="s"><a href=category.php?id=84> 教育/培训/咨询</a></div>
 
<div class="s"><a href=category.php?id=85> 广告/媒体/设计</a></div>
 
<div class="s"><a href=category.php?id=86> 建筑/装潢/园林</a></div>
 
<div class="s"><a href=category.php?id=87> 编辑</a></div>
 
<div class="d"><a href=category.php?id=88> 摄影</a></div>
 
<div class="d"><a href=category.php?id=89> 翻译</a></div>
 
<div class="s"><a href=category.php?id=90> 美容美发</a></div>
 
<div class="s"><a href=category.php?id=91> 保健按摩</a></div>
 
<div class="s"><a href=category.php?id=92> 招聘会</a></div>
 
<div class="s"><a href=category.php?id=93> KTV/酒吧</a></div>
 
<div class="s"><a href=category.php?id=94> 其他招聘</a></div>

<div class="blank"></div><div style="border-bottom:1px solid #E1E1E1; border-top:1px solid #E1E1E1; margin-bottom:5px;">
<h3 style="margin:0; background:#F1F1F1; border:1px solid #FFF;" >
<span style="background-position:-40px 0;"></span>
<a href="category.php?id=10">求职简历</a>
</h3>
</div>
<div class="s"><a href=category.php?id=175> 全职求职简历</a></div>
<div class="s"><a href=category.php?id=176> 兼职求职简历</a></div>
<div class="blank"></div>
</td><td valign="top">
<div style="border-bottom:1px solid #E1E1E1;  margin-bottom:5px;">
<h3 style="margin:0; background:#F1F1F1; border:1px solid #FFF;" >
<span style="background-position:-40px 0;"></span>
<a href="category.php?id=5">生活服务</a>
</h3>
</div>
<div class="d"><a href=category.php?id=95> 租车</a></div>
 
<div class="d"><a href=category.php?id=96> 驾校</a></div>
 
<div class="d"><a href=category.php?id=97> 陪驾/代驾</a></div>
 
<div class="s"><a href=category.php?id=98> 汽车检修/保养</a></div>
 
<div class="s"><a href=category.php?id=99> 家政保姆服务</a></div>
 
<div class="s"><a href=category.php?id=100> 保洁清洗服务</a></div>
 
<div class="d"><a href=category.php?id=101> 装修</a></div>
 
<div class="d"><a href=category.php?id=102> 疏通</a></div>
 
<div class="s"><a href=category.php?id=103> 建材装饰</a></div>
 
<div class="s"><a href=category.php?id=104> 家居维修</a></div>
 
<div class="d"><a href=category.php?id=105> 搬家</a></div>
 
<div class="d"><a href=category.php?id=106> 快递/物流</a></div>
 
<div class="s"><a href=category.php?id=107> 电脑维修</a></div>
 
<div class="s"><a href=category.php?id=108> 家电维修</a></div>
 
<div class="s"><a href=category.php?id=109> 招商加盟/代理</a></div>
 
<div class="s"><a href=category.php?id=110> 公司注册/年检</a></div>
 
<div class="s"><a href=category.php?id=111> 担保/贷款</a></div>
 
<div class="s"><a href=category.php?id=112> 投资理财/保险</a></div>
 
<div class="s"><a href=category.php?id=113> 会计/审计/评估</a></div>
 
<div class="d"><a href=category.php?id=114> 旅游</a></div>
 
<div class="d"><a href=category.php?id=115> 酒店</a></div>
 
<div class="s"><a href=category.php?id=116> 机票/签证</a></div>
 
<div class="s"><a href=category.php?id=117> 网站建设/推广</a></div>
 
<div class="d"><a href=category.php?id=118> 鲜花</a></div>
 
<div class="d"><a href=category.php?id=119> 礼品/定制</a></div>
 
<div class="s"><a href=category.php?id=120> 美容纤体</a></div>
 
<div class="s"><a href=category.php?id=121> 婚庆/化妆/司仪</a></div>
 
<div class="s"><a href=category.php?id=122> 摄影服务</a></div>
 
<div class="s"><a href=category.php?id=123> 设计策划</a></div>
 
<div class="s"><a href=category.php?id=124> 印刷/喷绘招牌</a></div>
 
<div class="d"><a href=category.php?id=125> 翻译</a></div>
 
<div class="d"><a href=category.php?id=126> 律师</a></div>
 
<div class="s"><a href=category.php?id=127> 物品/设备租赁</a></div>
 
<div class="s"><a href=category.php?id=128> 物品回收</a></div>
 
<div class="s"><a href=category.php?id=129> 其他服务</a></div>
 
<div class="s"><a href=category.php?id=138> 技能交换</a></div>
<div class="blank"></div>
</td></tr>
 
</table></div>
 
<div class="blank10"></div>
 
  <DIV id=cities>
    <TABLE id=cities cellSpacing=10 cellPadding=0>
      <TBODY>
        <TR>
          <TH>区域选择
          <TD> <?php if(is_array($areas_list)) foreach($areas_list AS $val) { ?> <a href="<?php echo $val['url'];?>"><?php echo $val['areaname'];?></a>&nbsp;&nbsp; 
<?php } ?>
 </td>
        </TR>
      </TBODY>
    </TABLE>
  </DIV>
  <DIV class=link id=InnerLink style="BORDER-TOP: #ccc 1px solid"></DIV>
  <DIV class=link id=SourceLink>友情链接： <?php if(!empty($links[txt])) { ?> <?php if(is_array($links[txt])) foreach($links[txt] AS $link) { ?> <a href="<?php echo $link['url'];?>" target=_blank title="<?php echo $link['webname'];?>"><?php echo $link['webname'];?></a> 
<?php } ?>
 <?php } ?>&nbsp;|&nbsp;&nbsp;
客服QQ：
    <?php if(!empty($CFG['qq'])) { ?>
    <?php if(is_array($CFG['qq'])) foreach($CFG['qq'] AS $qq) { ?>
    <a href="http://wpa.qq.com/msgrd?V=1&amp;Uin=<?php echo $qq;?>&amp;Site=<?php echo $CFG['webname'];?>&amp;Menu=yes" target="_blank"><img style="display:inline" src="http://wpa.qq.com/pa?p=1:<?php echo $qq;?>:4" height="16" border="0" alt="QQ" /><?php echo $qq;?></a>
    
<?php } ?>

    <?php } ?>
</div>
 
</div><!-- content -->
<script>document.getElementById('content').style.height = 'auto';</script>
 
<div id="subfooter"></div><!--subfooter-->
</div><!--E:container-->

<!-- 主体 结束 -->

<?php include template(footer); ?>

</BODY>
</HTML>

