<?php if(!defined('IN_PHPMPS'))die('Access Denied'); ?><?php if(is_array($ads)) foreach($ads AS $ad) { ?>
<?php echo $ad;?>

<?php } ?>

