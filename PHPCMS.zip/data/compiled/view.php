<?php if(!defined('IN_PHPMPS'))die('Access Denied'); ?>﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml">
<HEAD>
<title><?php echo $seo['title'];?></title>
<meta name="Keywords" content="<?php echo $seo['keywords'];?>">
<meta name="Description" content="<?php echo $seo['description'];?>">
<link href="templates/<?php echo $CFG['tplname'];?>/images/tcw.css" type="text/css" rel="stylesheet" />
<META content="MSHTML 6.00.6000.17063" name=GENERATOR>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset;?>" />
<script type="text/javascript" src="js/jquery.js"></script>
<!-- phpmps -->
<script> 
var lng = '<?php echo $mappoint['0'];?>';
var lat = '<?php echo $mappoint['1'];?>';
var address = '信息所在地';
function checkcomment()
{
if(document.comment.content.value==""){
alert('请输入评论内容！');
document.comment.content.focus();
return false;
}
if(document.comment.checkcode.value==""){
alert('请输入验证码！');
document.comment.checkcode.focus();
return false;
}
}
function chkreport()
{
var radios = document.getElementsByName("types"); 
var resualt = false;
for(i=0;i<radios.length;i++)
{
if(radios[i].checked)
{
    resualt = true;
}
}
if(!resualt)
{   
alert("请选择错误类型");
return false;
}
}
function chktype()
{
if(document.form3.password.value==""){
alert('请输入密码！');
document.form3.password.focus();
return false;
}
if(document.form3.act.value=="delinfo"){
return confirm('确认要删除吗？此操作不可恢复！')
}
}
</script>
</HEAD>
<BODY>

<?php include template(header); ?>

<!--navi-->
<div id="container">
  <div id="subheader">
    <script type="text/javascript" src="/ad/ads.js"></script>
      <h1 style="display: inline;"><?php echo $title;?></h1>
    <div class="line"></div>
  </div>
  <!-- subheader -->
  <div id="content" style="height:1000px;">
    <div id="left">
      <div id="commentBox" style="line-height:20px;font-size:12px;float:right;background:white;" class="dh_hide">
        <div style="padding:2px 8px 2px 0;">
        </div>
        <div style="padding:2px 8px;">
          <div id="jubaoBox"></div>
        </div>
        <div style="padding:2px 8px;">
          <div id="surveyBox"></div>
        </div>
      </div>
      <!-- google_ad_section_start -->
      <table width="100%" id="metaTable">
        <tbody>
          
          <tr>
            <td class="short"><label>发布时间：</label>
              <?php echo $postdate;?> <span class="red_skin"><?php echo $infousername;?></td>
            <td 
 
class="short"><label>查看次数：</label>
              <span id="counter"><?php echo $click;?></span></td>
          </tr>
          <tr>
            <td class="short"><label>地区/栏目 ：</label>
              <a href="category.php?id=<?php echo $areaid;?>" title="浏览更多<?php echo $areaname;?>信息"><?php echo $areaname;?></a> / <a href="category.php?area=<?php echo $catid;?>" title="浏览更多<?php echo $catname;?>信息"><?php echo $catname;?></a> </td>
            <td class="short"><label>信息编号：</label>
              <?php echo $id;?></td>
          </tr>
          <tr>
            <td class="short"><label>有效期：</label>
              <?php echo $lastdate;?></td>
            <td>
<!--Passit BUTTON BEGIN-->
<!-- Baidu Button BEGIN -->
    <div id="bdshare" class="bdshare_b" style="line-height: 12px;margin-left:16px;"><img src="http://share.baidu.com/static/images/type-button-8.jpg" /></div>
    <script type="text/javascript" id="bdshare_js" data="type=button&amp;mini=1&amp;uid=11450" ></script>
    <script type="text/javascript" id="bdshell_js"></script>
    <script type="text/javascript">
        document.getElementById("bdshell_js").src = "http://share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();
    </script>
<!-- Baidu Button END --> 
<script type="text/javascript"> 
var passit_title = "";//自定义分享标题，删除和留空表示使用默认
var passit_url = "";//自定义分享网址，删除和留空表示使用默认
var passit_content= "";//自定义分享内容，删除和留空表示使用默认Meta中的描述
var passit_image= "";//自定义分享图片，删除和留空表示不分享图片
</script>
<script type="text/javascript">
bookmark_service_div="kxzt,qqxy,baiduHi,bookmark,baidu,douban,sohuweibo,163weibo,qqweibo,more";
bookmark_service="qqkj,sinaweibo,xnzt,qq,more";</script>
<script type="text/javascript" src="http://www.passit.cn/js/passit_bar_new.js?pub=0&passit_size=16&simple=1" charset="UTF-8"></script>
<!--Passit BUTTON END-->
</td>
          </tr>
        </tbody>
      </table>
      <div class="blank10"></div>
       <div class="cont_main">
                  <table width="100%" class="table_1" border="0" cellspacing="0">
  <?php if(is_array($custom)) foreach($custom AS $val) { ?>
  <tr>
<td align="right" bgcolor="#eff1f7" width="100px"><b><?php echo $val['name'];?>：</b></td>
<td align="left"><?php echo $val['value'];?>&nbsp;&nbsp;<?php echo $val['unit'];?></td>
  </tr>
  
<?php } ?>

  </table>
<?php echo $content;?>&nbsp;<?php echo $address;?><br /><br /><b>联系方式：</b><span style="font-family: Impact, "Arial Black", Arial;font-weight: bold;color: #000000;"><font size=5><?php echo $phone_c;?></font></span><?php echo $linkman;?>&nbsp;
<a href="http://wpa.qq.com/msgrd?V=1&amp;Uin=<?php echo $qq_c;?>&amp;Site=南通百有网(www.baiuo.net)&amp;Menu=yes" target="_blank"><img style="display:inline" src="http://wpa.qq.com/pa?p=1:<?php echo $qq_c;?>:4" height="16" border="0" alt="QQ" /></a>

<?php echo $qq_c;?></a><br />打电话给我时，请说明在提爱你谁信息网(info.itianshui.com)看到的，谢谢！</span><br /><br />
<div class="block">
        <div class="b">
          <table width="100%">
            <tr>
              <td width="98%">
 <a style="color:red">天水信息网友情提示：交易最好当面，切勿上当受骗！</a>
              </td>
              <td width="30%" align="right" style="vertical-align:middle"></td>
            </tr>
          </table>
        </div>
      </div>
<?php if($images) { ?>
<?php if(is_array($images)) foreach($images AS $val) { ?>
<div style="float:left;border:1px solid #cccccc; margin:10px 20px 10px 0;"><a href=<?php echo $val['path'];?> target="_blank" ><img src=<?php echo $val['path'];?> alt="<?php echo $title;?>" width="300px;" height="235px" hspace="5" vspace="5" border=0 class="postinfoimg" /></a></div>

<?php } ?>

<?php } ?>
  </div>
<style> 
.shareBox{display: none;padding: 5px;margin-top: 10px;background: #f1f1f1;width: 420px;color: #333;-moz-border-radius: 4px;-webkit-border-radius: 4px;}
</style>
      <div class="blank10"></div>
<!-- 广告位: (728 x 90) -->
      <div class="blank10"></div>
      <div style="clear:both;border-top: 1px solid rgb(235, 235, 235);padding: 5px;font-size:12px;" class="dh_hide"> 信息编号：<span id="adId"><?php echo $id;?> &nbsp; 查看次数：<?php echo $click;?></span> </div>
      <!--E:manage-->
      <script>document.getElementById('content').style.height = 'auto';</script>
      <div id="followHistory" style="border-top: 1px solid #ebebeb;margin-top: 10px;padding: 5px 0 0 5px;"> <small> 温馨提示：此信息为网友发布，信息请自辨真假，如有损失，本站概不负责。<br />
        如果您发现这条信息有问题，请举报。 </small>
        <form name="report" method="post" action="member.php" onSubmit="return chkreport()">
          <input type="radio" name="types" value="1">
          非法信息
          <input type="radio" name="types" value="2">
          分类错误
          <input type="radio" name="types" value="4">
          信息失效
          <input type="hidden" name="id" value="3565">
          <input type="hidden" name="act" value="report">
          <input type="submit" name="submit" value="提交">
        </form>
      </div>
      <div id="followHistory" style="border-top: 1px solid #ebebeb;margin-top: 10px;padding: 5px 0 0 5px;"> 
  <small> 填写信息的删除密码，即可修改或删除此信息。 </small>
                    <form name=form3 action="member.php?act=editinfo" method=post>密码: 
<input name=password type=password id=delpass size="10" maxLength=20>
<select name="act" id="act">
  <option value="delinfo">删除</option>
  <option value="editinfo">修改</option>
</select>
<input onClick="return chktype();" type=submit value="提交" name=submit>
<input type=hidden name=id value=<?php echo $id;?> />
</form>
      </div>
      <div class="blank10"></div>
      <a name="1"></a>
  
      <div class="datagrid" style="border:1px solid #ccc;">
        <ol>
          <li class="head"><a target="_blank" rel="nofollow" style="padding-right: 5px; float: right; font-weight: normal; font-size: 12px;" href="/ad/">我想在此投放广告</a><a target="_blank" href="/ad/">广告赞助商</a></li>
          
        </ol>
        <div class="blank10"></div>
      </div>
  
  
    </div>
    <!--left-->
    <DIV id=right>
  <DIV class=block>
    <DIV class=b>
 你可以对信息进行：
     <table>
            <tr>
              <td style="padding-left:8px;" colspan='1'>· <a href="#1" rel="nofollow">修改</a></td>
              <td style="padding-left:8px;" colspan='1'>· <a href="#1" rel="nofollow">删除</a></td>
            </tr>
            <tr>
              <td style="padding-left:8px;" colspan='2'>· <a href="#1">举报此信息 [?]</a></td>
            </tr>
            <tr>
              <td style="padding-left:8px;" colspan='2'>· <a href="member.php?act=info" target="_blank" style="color:red" rel="nofollow">免费刷新</a></td>
            </tr>
          </table>
</DIV>
  </DIV>
  <DIV class=blank10></DIV>
  <DIV class=blank10></DIV>
  <DIV class=descr>
    <!-- 广告位: (160 x 600) -->
  </DIV>
  <DIV class=blank10></DIV>
  <DIV class=block>
    <DIV class=b>
      <UL>
        当前大家都在看什么？<BR>
   <?php if(is_array($cat_hot)) foreach($cat_hot AS $hot) { ?>
<li><a href="<?php echo $hot['url'];?>" target="_blank"><?php echo $hot['title'];?></a></li>
   
<?php } ?>

      </UL>
    </DIV>
  </DIV>
</DIV>
    <div class="blank10"></div>
    <div style="clear:both;"></div>
  </div>
  <!--content-->
  <div id="subfooter">
    <DIV id=cities>
      <TABLE id=cities cellSpacing=10 cellPadding=0>
        <TBODY>
          <TR>
            <TH>区域选择
            <TD> <?php if(is_array($areas_list)) foreach($areas_list AS $val) { ?> <a href="<?php echo $val['url'];?>"><?php echo $val['areaname'];?></a>&nbsp;&nbsp; 
<?php } ?>
 </td>
          </TR>
        </TBODY>
      </TABLE>
    </DIV>
  </div>
  <!--subfooter-->
</div>
<!-- 主体 结束 -->

<?php include template(footer); ?>

</BODY>
</HTML>

