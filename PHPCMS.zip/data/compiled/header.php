<?php if(!defined('IN_PHPMPS'))die('Access Denied'); ?><DIV id=header_bar>
  <DIV id=header_bar_inner align="left"><SPAN><?php echo $CFG['copyright'];?></SPAN>
    <DIV id=header_links><SPAN id=hello>
      <?php if($_SESSION['userid']) { ?>
&nbsp;&nbsp;欢迎你：<?php echo $_username;?> &nbsp;&nbsp;<a href="member.php">[个人中心]</a> &nbsp;&nbsp;<a href="member.php?act=logout&mid=<?php echo $_userid;?>">[退出]</a>
      <?php } else { ?>
      <font color="red"><a href="member.php?act=login&refer=<?php echo $PHP_URL;?>">登录</a></font>&nbsp;|&nbsp; <font color="red"><a href="member.php?act=register">注册</a></font>
      <?php } ?>
      </SPAN></DIV>
  </DIV>
</DIV>
<DIV id=header align="left"><A id=logo title="<?php echo $seo['title'];?>" href="/" target=_self><IMG src="templates/<?php echo $CFG['tplname'];?>/images/logo.jpg"> </A>
  <DIV id=base_header_banner style="LEFT: 250px; WIDTH: 468px; POSITION: absolute; TOP: 10px; HEIGHT: 60px;"><?php echo ads_list('1');?></DIV>
  <DIV style="RIGHT: 0px; POSITION: absolute; TOP: 20px! important; HEIGHT: 30px; _right: -6px">
    <DIV style="PADDING-RIGHT: 4px; PADDING-LEFT: 4px; PADDING-BOTTOM: 7px; PADDING-TOP: 5px; BACKGROUND-COLOR: #e7e7ca; _padding: 5px 3px 6px 4px"><A 
class=btn_green style="magin-right: 3px" href="/post.php" rel=nofollow alt="免费发布信息">免费发布信息</A> <A class=btn_normal href="/" target=_self rel=nofollow>广告投放/置顶</A></DIV>
  </DIV>
</DIV>
<!--header-->
<DIV id=navi>
  <DIV class=b>
    <?php if(is_array($nav)) foreach($nav AS $nav) { ?>
    <a href="<?php echo $nav['url'];?>" target="<?php echo $nav['target'];?>"><?php echo $nav['navname'];?></a>
    
<?php } ?>

    <A style="FONT-SIZE: 14px; FLOAT: right" href="/member.php" target=_blank rel=nofollow>会员中心</A>
    <DIV class=blank></DIV>
  </DIV>
  <STYLE> 
</STYLE>
</DIV>
