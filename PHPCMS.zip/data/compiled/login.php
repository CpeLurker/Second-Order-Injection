<?php if(!defined('IN_PHPMPS'))die('Access Denied'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="text/html; charset=gb2312" http-equiv="Content-Type"/>
<title>用户登陆</title>
<link href="templates/<?php echo $CFG['tplname'];?>/style/2011.css" rel="stylesheet" type="text/css" />
</head>
 
<body>
 
<style> 
#header {
position: relative;
height: 68px;
}
#header #header_location {
position: absolute;
left: 145px;
top: 25px;
padding: 0 10px;
border-left: 1px solid #C6C7B9;
}
#navi {
position: relative;
width:988px;
margin: 0 auto;
border-top: 1px solid #ccc;
border-left: 1px solid #ccc;
border-right: 1px solid #ccc;
background: url(/images/headerbg.jpg) repeat-x left top;
overflow: hidden;
}
#navi .b a, #navi .b a:visited {
float: left;
display: block;
padding: 5px 12px 5px 10px;
color: #FFFFBB;
text-decoration: none;
}
#navi .b a:hover {
color: #ecec7f;
 
}
#navi .b a.actv, #navi .b a.actv:visited {
background: white;
color: black;
}
 
#header_bar{
    background:#FFF;
    border-bottom:1px solid #CDCBBE;
}
#header_bar_inner{
    width:980px;
    margin:0 auto;
    font-size:12px;
    line-height:30px;
    height:30px;
    position:relative;
}
#header_bar_inner #header_links{
    position:absolute;
    right:0;
    bottom:0;
}
</style>

<?php include template(header); ?>

<!-- 主体 -->
<style> 
#filterTable tr {
background: #effaea;
}
#filterTable {
border-collapse:collapse;
}
#filterTable td{
border:1px #dbe2cb solid;
padding:4px 4px 4px 10px;
}
 
 
</style> 
 
 <div id="container">
 
<div id="subheader">
<h1>登陆</h1>
 
<div class="block nohist">
 
</div>
</div>
 
 

<div id="content">
<div id="left">
  <form method="post" action="member.php?act=act_login" class="form">
<table border="0" cellpadding="0" cellspacing="0">
 <tr class="row">
<td width="120" align="right" valign="top"><span class="red">*</span>用 户 名：</td>
<td><input type="text" maxlength="20" name="username" id="username" size="20" class="input" value="" /></td>
  </tr>
  <tr>
<td align="right" valign="top"><span class="red">*</span> 登录密码：</td>
<td><input type="password" maxlength="20" name="password" id="password" size="20" class="input" value="" />
</td>
<td></td>
  </tr>
  		  <tr>
<td align="right" valign="top"><span class="red">*</span> 问题验证：</td>
<td><input type="text" maxlength="20" name="answer" id="answer" size="20" class="input" value="" />&nbsp;<input type="hidden" id="vid" name="vid" value=<?php echo $verf['vid'];?> />

问题：<?php echo $verf['question'];?>？&nbsp;</td>
<td></td>
  </tr>
  
  
  <tr>
<td align="right" valign="top">&nbsp;</td>
<td colspan="2"><input type="hidden" name="refer" value="<?php echo $refer;?>" />
<input type="submit" id="submit" name="submit" value="点击登录" />&nbsp;&nbsp;
 
<div class="blank10"></div>
<div class="blank10"></div>
如你未在本站注册过用户名，请<a href="/member.php?act=register">点此注册</a>！
</td>
  </tr>
</table>
  </form>
</div>
<div id="right">
<div class="descr">
 
</div>
</div><!--right-->
 
<div class="blank"></div>
 
</div>
 
<div id="subfooter"></div><!--subfooter-->
 
</div><!--E:container-->
<div class="phpmpslogin">
<?php include template(footer); ?>
</div>
<script type="text/javascript"> 
$.validator("username")
.setRequired("请填写用户名。")
.setServerCharset("GBK")
.setStrlenType("byte")
 
$.validator("password")
.setRequired("请填写密码。")
.setServerCharset("gbk")
.setStrlenType("symbol")
 
$.validator("answer")
.setRequired("请填写问题验证。")
.setAjax("do.php?act=ver&vid="+$('#vid').val(), "回答不正确。");
</script>
</body>
</html>