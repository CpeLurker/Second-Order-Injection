<?php if(!defined('IN_PHPMPS'))die('Access Denied'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset;?>" />
<title><?php echo $seo['title'];?></title>
<meta name="Keywords" content="<?php echo $seo['keywords'];?>">
<meta name="Description" content="<?php echo $seo['description'];?>">
<link href="templates/<?php echo $CFG['tplname'];?>/style/2011.css" rel="stylesheet" type="text/css" />

<script src="js/common.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
</head>
 
<style> 
#header {
position: relative;
height: 68px;
}
#header #header_location {
position: absolute;
left: 145px;
top: 25px;
padding: 0 10px;
border-left: 1px solid #C6C7B9;
}
#navi {
position: relative;
width:988px;
margin: 0 auto;
border-top: 1px solid #ccc;
border-left: 1px solid #ccc;
border-right: 1px solid #ccc;
background: url(/images/headerbg.jpg) repeat-x left top;
overflow: hidden;
}
#navi .b a, #navi .b a:visited {
float: left;
display: block;
padding: 5px 12px 5px 10px;
color: #FFFFBB;
text-decoration: none;
}
#navi .b a:hover {
color: #ecec7f;
 
}
#navi .b a.actv, #navi .b a.actv:visited {
background: white;
color: black;
}
 
#header_bar{
    background:#FFF;
    border-bottom:1px solid #CDCBBE;
}
#header_bar_inner{
    width:980px;
    margin:0 auto;
    font-size:12px;
    line-height:30px;
    height:30px;
    position:relative;
}
#header_bar_inner #header_links{
    position:absolute;
    right:0;
    bottom:0;
}
</style>
 
</head>
<body>
 
 

<?php include template(header); ?>

 
 
<style> 
#filterTable tr {
background: #effaea;
}
#filterTable {
border-collapse:collapse;
}
#filterTable td{
border:1px #dbe2cb solid;
padding:4px 4px 4px 10px;
}
 
 
</style>
<!-- 主体 -->
<div id="container">
<div id="content" class="clearfix">
<div class="col_main">
<div class="edit_box">
<div id="contentfloat">
        <div>
<div class="bigtitle">我的信息管理</div>
 
<table width="100%" cellpadding="0" cellspacing="0" class="tx_box">
<tr>
<td valign="top" style="width:70px; text-align:center;"><img src="templates/<?php echo $CFG['tplname'];?>/images/icon1.gif" width="53" height="53" alt="" /></td>
<td class="tx_title"><span>重要提示：</span><br />
您可以编辑、删除您自己发布的信息
 
<br />
</td>
</tr>
</table>
<span ><div class="ptag"></div><br /></span><table id="ProOrderList" width="100%">
<tr>
<td>          
        <table border="0" cellpadding="1" cellspacing="1" class="tablelist" width="100%">
            <tr class="tabletitle">
                <td width="10%"><b>信息编号</b></td>
                <td width="40%"><b>信息标题</b></td>
<td width="5%"><b>推荐</b></td>
<td width="5%"><b>置顶</b></td>
<td width="5%"><b>审核</b></td>
                <td width="13%"><b>发布时间</b></td>
                <td width="20%"><b>操作</b></td>
            </tr>
<?php if(is_array($infos)) foreach($infos AS $info) { ?>
<tr class="tditem" style="text-align:center;" onmouseover="this.className='table_over';" onmouseout="this.className='tditem';">
<td><?php echo $info['id'];?></td>
<td><a href="<?php echo $info['url'];?>" target="_blank"><?php echo $info['title'];?></a></td>
<td><?php echo $info['is_pro'];?></td>
<td><?php echo $info['is_top'];?></td>
<td><?php echo $info['is_check'];?></td>
<td><?php echo $info['postdate'];?></td>
<td align="center"><a href="member.php?act=editinfo&id=<?php echo $info['id'];?>">编辑</a>|<a href="member.php?act=delinfo&id=<?php echo $info['id'];?>" onClick="if(!confirm('确定要删除吗？\n\n此操作不可以恢复！'))return false;">删除</a>|<a href="member.php?act=refer&id=<?php echo $info['id'];?>">一键刷新</a>|<a href="member.php?act=top&id=<?php echo $info['id'];?>">置顶</a></td>
</tr>

<?php } ?>

        </table>
    <div class="manu clearfix" style="text-align:center;">

<?php include template(page); ?>

</div></td>
</tr>
</table>
        </div>　
</div>
</div>
</div>
<div class="col_sub">
<!-- 侧边栏菜单 开始 -->
<div class="side_bar">
<ul>
 
<a href="member.php">会员首页</a>
><a href="member.php?act=modify">基本资料</a>
><a href="member.php?act=edit_password">修改密码</a>
><a href="member.php?act=payonline">在线充值</a>
><a href="member.php?act=gold">购买信息币</a>
><a href="member.php?act=credit_rule">积分规则</a>
><a href="member.php?act=exchange">交易详情</a>
><a href="member.php?act=info">我的信息</a> <a href="post.php" class="small">发布</a>
><a href="member.php?act=info_comment">信息评论</a> 
><a href="member.php?act=logout">退出系统</a>
</ul>
</div>
<!-- 侧边栏菜单 结束 -->
</div>
</div>
</form>
<!-- 主体 结束 -->
<div id="subfooter"></div>

<?php include template(footer); ?>

</div>
</body>
</html>

