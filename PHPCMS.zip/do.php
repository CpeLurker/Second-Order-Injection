<?php
define('IN_PHPMPS', true);
require dirname(__FILE__) . '/include/common.php';
require dirname(__FILE__) . '/include/pay.fun.php';

$_REQUEST['act'] = $_REQUEST['act'] ? trim($_REQUEST['act']) : '' ;

switch($_REQUEST['act'])
{
	case 'small_map':
		include template('map');
	break;

	case 'show':
		$out   = decrypt($_REQUEST['num'], $CFG['crypt']);
		$hight = strlen($out)*10;
		$image = imagecreate($hight, 20);
		$bg    = imagecolorallocate($image, 255, 255, 255);
		$textcolor = imagecolorallocate($image, 55, 55, 55);
		imagestring($image, 5, 0, 3, $out, $textcolor);
		header("Content-type: image/png");
		imagepng($image);
	break;

	case 'chkcode':
		$_SESSION["chkcode"] = "";
		$chkcode = chkcode();
		$_SESSION["chkcode"] = $chkcode;
	break;

	case 'checkcode':
		$json = new Services_JSON;
		$chkcode = $_SESSION["chkcode"];
		$checkcode = trim($_REQUEST['checkcode']);
		if(empty($chkcode) || $chkcode != $checkcode) {
			echo $json->encode('0');
			exit;
		} else {
			echo $json->encode('1');
			exit;
		}
	break;

	case 'ver':
		require PHPMPS_ROOT . 'include/json.class.php';
		$answer = iconvs('utf8', 'gbk', trim($_REQUEST['answer']));
		$vid = intval($_REQUEST['vid']);
		$ver = get_ver();
		$verf = $ver[$vid];
		$a = $answer == $verf['answer'] ? true : false;
		$json = new Services_JSON;
		echo $json->encode($a);
		exit;
	break;
}
?>