<?php

if (!defined('IN_PHPMPS'))
{
    die('Access Denied');
}

$VERSION = array (
    'version'=>'2.2',
    'release'=>'20110517',
);
?>