<?php
defined('IN_PHPMPS') or exit('Access Denied');

$orderid = date('Ymd').'-'.$partnerid.'-'.date('his');
?>